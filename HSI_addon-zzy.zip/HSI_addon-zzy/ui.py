# coding=UTF-8
# dont direct regist example class.

import bpy
from bpy.types import Operator, AddonPreferences, Panel, PropertyGroup
from bpy.props import StringProperty, BoolProperty, IntProperty, CollectionProperty, BoolVectorProperty, PointerProperty, EnumProperty
import json

class HSI_PT_main_panel(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "HSI"
    bl_label = "Human-Scene Interaction"

    def draw(self, context):
        pass


class HSI_PT_character(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "HSI"
    bl_label = "Character"
    bl_parent_id = "HSI_PT_main_panel"

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        layout.prop(scene.hsi_properties, "shogun_fbx_path")
        layout.operator('hsi.calculate_cc_slider_values')
        layout.prop(scene.hsi_properties, "cc4_fbx_path")
        layout.operator('hsi.import_cc4_fbx')
        layout.label(text='Current CC armature:')
        row = layout.row(align=True)
        row.prop_search(scene.hsi_properties, "name_armature_CC",
                        bpy.data, "objects", text="")
        row.operator('hsi.pick_cc_armature', text="", icon='EYEDROPPER')
        layout.operator('hsi.calibrate_cc_shogun_armatures')
        layout.operator('hsi.remove_character')


class HSI_PT_record(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "HSI"
    bl_label = "Record"
    bl_parent_id = "HSI_PT_main_panel"

    def draw(self, context):
        scene = context.scene
        layout = self.layout

        layout.label(text='Recoding settings:')
        layout.prop(scene.hsi_properties, "recordings_path")
        layout.prop(scene.hsi_properties, 'recording_fps')
        layout.prop(scene.hsi_properties, 'maximum_framenum')
        layout.prop(scene.hsi_properties, 'shogun_subject_name')
        row = layout.row()
        row.operator('hsi.activate_marker_debug')
        row.operator('hsi.deactivate_marker_debug')

        layout.label(text='Recording:')
        layout.operator('wm.live_modal_timer_operator')
        layout.operator('hsi.stop_livestream')
        # layout.prop(scene.hsi_properties,"language_instructions" )
        layout.operator('wm.record_modal_timer_operator')
        layout.operator('hsi.end_recording')
        


class HSI_PT_instruction(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "HSI"
    bl_label = "Language"
    bl_parent_id = "HSI_PT_main_panel"
    # bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        # layout.label(text='VR Settings:')
        # row=layout.row(align=True)
        # row.prop_search(scene.hsi_properties, "name_VR_camera", bpy.data, "objects", text="")
        # row.operator('hsi.pick_vr_camera',text="",icon='EYEDROPPER')
        # layout.operator('wm.calibrate_vr_modal_timer_operator')
        layout.prop(scene.hsi_properties, "scene_objects")
        layout.operator('hsi.generate_instructions')
        instructions = scene.hsi_properties.language_instructions.split('\n')
        layout.label(text='Instructions:')
        for i in range(len(instructions)):
            if i == context.scene.hsi_properties.current_instruction_index and context.scene.hsi_properties.streaming_state == 'RECORDING':
                layout.label(text=f'【{i+1}. ' + instructions[i] + '】')
            else:
                layout.label(text=f'{i+1}. ' + instructions[i])
        row = layout.row()
        row.label(text='Timepoints')
        row.label(text=scene.hsi_properties.instruction_timepoints)


class HSI_PT_restore(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "HSI"
    bl_label = "Restore"
    bl_parent_id = "HSI_PT_main_panel"
    # bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        layout.prop(scene.hsi_properties, "restore_file_path")
        # layout.operator('hsi.calibrate_cc_restore')
        layout.operator('hsi.restore_capture')
        layout.operator('hsi.apply_physics')
        layout.operator('hsi.remove_physics')
        layout.operator('hsi.clear_all_animation')
        layout.label(text='Edit animation set:')
        row=layout.row()
        row.prop(scene.hsi_properties, 'current_animation_index_display')
        row.operator('hsi.set_animation')
        layout.label(text='Existent animation set:')
        for index, animation_set_name in enumerate(json.loads(context.scene.hsi_properties.animation_sets)):
            if index == context.scene.hsi_properties.current_animation_index:
                layout.label(text=f'【{index} : {animation_set_name}】')
            else:
                layout.label(text=f'{index} : {animation_set_name}')
        layout.operator('hsi.remove_animation')
        layout.operator('hsi.load_smplx_animation')


class HSI_PT_VR(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "HSI"
    bl_label = "VR"
    bl_parent_id = "HSI_PT_main_panel"
    # bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        layout.label(text='VR Settings:')
        row = layout.row(align=True)
        row.prop_search(scene.hsi_properties, "name_VR_camera",
                        bpy.data, "objects", text="")
        row.operator('hsi.pick_vr_camera', text="", icon='EYEDROPPER')
        layout.operator('wm.calibrate_vr_modal_timer_operator')


classes = (
    HSI_PT_main_panel,
    HSI_PT_character,
    HSI_PT_record,
    HSI_PT_instruction,
    HSI_PT_restore,
    HSI_PT_VR,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)


if __name__ == '__main__':
    register()

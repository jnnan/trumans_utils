

import numpy as np

CC_BONE_NAMES = ['CC_Base_Hip', 'CC_Base_Pelvis',
 'CC_Base_Waist', 'CC_Base_Spine01', 'CC_Base_Spine02', 
 'CC_Base_NeckTwist01', 'CC_Base_NeckTwist02', 'CC_Base_Head', 

 'CC_Base_R_Clavicle', 'CC_Base_R_Upperarm', 'CC_Base_R_Forearm', 'CC_Base_R_Hand', 
 
 'CC_Base_R_Mid1', 'CC_Base_R_Mid2', 'CC_Base_R_Mid3', 'CC_Base_R_Ring1',
  'CC_Base_R_Ring2', 'CC_Base_R_Ring3', 'CC_Base_R_Pinky1', 'CC_Base_R_Pinky2',
   'CC_Base_R_Pinky3', 'CC_Base_R_Index1', 'CC_Base_R_Index2', 'CC_Base_R_Index3',
    'CC_Base_R_Thumb1', 'CC_Base_R_Thumb2', 'CC_Base_R_Thumb3',
                 
    'CC_Base_L_Clavicle', 'CC_Base_L_Upperarm', 'CC_Base_L_Forearm', 'CC_Base_L_Hand', 
    'CC_Base_L_Mid1', 'CC_Base_L_Mid2', 'CC_Base_L_Mid3', 
     'CC_Base_L_Ring1', 'CC_Base_L_Ring2', 'CC_Base_L_Ring3',
      'CC_Base_L_Pinky1', 'CC_Base_L_Pinky2', 'CC_Base_L_Pinky3', 
      'CC_Base_L_Index1', 'CC_Base_L_Index2', 'CC_Base_L_Index3', 'CC_Base_L_Thumb1', 
      'CC_Base_L_Thumb2', 'CC_Base_L_Thumb3', 'CC_Base_R_Thigh', 
      'CC_Base_R_Calf', 'CC_Base_R_Foot', 
      'CC_Base_L_Thigh',
       'CC_Base_L_Calf', 'CC_Base_L_Foot', 
      'CC_Base_R_ToeBase', 
       'CC_Base_L_ToeBase',
]




def rigid_transform_3D(A, B, scale):
    assert len(A) == len(B)

    N = A.shape[0]  # total points

    centroid_A = np.mean(A, axis=0)
    centroid_B = np.mean(B, axis=0)

    # center the points
    AA = A - np.tile(centroid_A, (N, 1))
    BB = B - np.tile(centroid_B, (N, 1))

    # dot is matrix multiplication for array
    if scale:
        H = np.transpose(BB) * AA / N
    else:
        H = np.transpose(BB) * AA

    U, S, Vt = np.linalg.svd(H)

    R = Vt.T * U.T

    # special reflection case
    if np.linalg.det(R) < 0:
        print("Reflection detected")
        Vt[2, :] *= -1
        R = Vt.T * U.T

    if scale:
        varA = np.var(A, axis=0).sum()
        c = 1 / (1 / varA * np.sum(S))  # scale factor
        t = -R * (centroid_B.T * c) + centroid_A.T
    else:
        c = 1
        t = -R * centroid_B.T + centroid_A.T

    M = np.concatenate([R, t], axis=1)
    M = np.concatenate([M, np.array([[0., 0., 0., 1.]])], axis=0)

    return c, M

# Define the list of actions and objects

# scene_objects= ['瓶子', '手机', '显示器'  , '椅子',
#                    '冰箱',       '显示器', '白板', ]
import random


    # "ACTIONS": [
    #     "抓取",
    #     "拿起",
    #     "放下",
    #     "喝",
    #     "坐在",
    #     "看",
    #     "靠打电话",
    #     "写",
    #     "打字",
    #     "使用",
    #     "打开",
    #     "关闭",
    #     "躺在",
    #     "站起来",
    #     "休息",
    #     "走来走去",
    #     "把...放进...",
    #     "把...移动到...",
    #     "切换...和...",
    #     "从...取出..."
    # ],

# OBJECTS = ['瓶子', '手机', '笔记本电脑', '笔', '书', '键盘', '鼠标',         '椅子', '桌子', '床', '沙发',
#            '包',  '微波炉', '烤箱', '抽屉', '冰箱',  '柜子',           '显示器', '白板', ]
# OBJECT_COUNTS = {
#     '抓取': 1,
#     '拿起': 1,
#     '放下': 1,
#     '喝': 1,
#     '坐在': 1,
#     # '短信': 1,
#     '打电话': 1,
#     '写': 1,
#     '打字': 1,
#     '使用': 1,
#     '打开': 1,
#     '关闭': 1,
#     '躺在': 1,
#     '看': 1,

#     '站起来': 0,
#     '休息': 0,
#     '走来走去': 0,

#     '把...放进...': 2,
#     '把...移动到...': 2,
#     '切换...和...': 2,
#     '从...取出...': 2,
# }

# APPLICABLE_OBJECTS = {
#     '抓取': ['瓶子', '手机', '笔记本电脑', '笔', '键盘', '鼠标'],
#     '拿起': ['瓶子', '手机', '笔记本电脑', '笔', '键盘', '鼠标', '包'],
#     '放下': ['瓶子', '手机', '笔记本电脑', '笔', '键盘', '鼠标', '包', ],
#     '喝': ['瓶子'],
#     '坐在': ['椅子', '床'],
#     # '短信': [ ],
#     '打电话': ['手机'],
#     '写': ['笔'],
#     '打字': ['手机', '键盘', '笔记本电脑'],
#     '使用': ['手机', '笔记本电脑', '笔', '键盘', '鼠标'],
#     '打开': ['抽屉', '冰箱', '微波炉', '烤箱', '柜子'],
#     '关闭': ['抽屉', '冰箱', '微波炉', '烤箱', '柜子'],
#     '躺在': ['床'],
#     '站起来': [],
#     '休息': [],
#     '走来走去': [],
#     '看': ['手机', '显示器', '书', ],
#     '靠':['椅子','桌子'],
#     '把...放进...': [['瓶子', '手机', '笔记本电脑', '笔', '书', '键盘', '鼠标'], ['微波炉', '烤箱', '抽屉', '冰箱',  '柜子']],
#     '把...移动到...': [['瓶子', '手机', '笔记本电脑', '笔', '书', '键盘', '包', '椅子', '鼠标'], ['微波炉', '烤箱', '抽屉', '冰箱',  '柜子', '桌子']],
#     '切换...和...': [['瓶子', '手机', '笔记本电脑', '笔', '书', '键盘', '鼠标', '包'], ['瓶子', '手机', '笔记本电脑', '笔', '书', '键盘', '鼠标', '包']],
#     '从...取出...': [['微波炉', '烤箱', '抽屉', '冰箱',  '柜子'], ['瓶子', '手机', '笔记本电脑', '笔', '书', '键盘', '鼠标']]
# }

import json
import os
def generate_instruction(scene_objects, instruction_num=5):
    path = os.path.dirname(os.path.realpath(__file__))
    with open(os.path.join(path,'instrucion_dict.json'), 'r', encoding='GB2312') as f:
        saved_dict = json.load(f)
    objects = saved_dict['OBJECTS']
    object_counts = saved_dict['OBJECT_COUNTS']
    applicable_objects = saved_dict['APPLICABLE_OBJECTS']

    partial_objects = scene_objects
    for obj in partial_objects:
        if obj not in objects:
            print(obj)
            raise ValueError(f"incorrect obj \"{obj}\"")
    # actions = ACTIONS

    def simple_clause():
        while True:
            action = random.choice(partial_actions)
            count = object_counts[action]
            if count == 0:
                return f'{action}', action, []
            elif count == 1:
                obj = random.choice(partial_applicable_objects[action])
                return f'{action} {obj}', action, [obj]
            elif count == 2:
                obj1 = random.choice(partial_applicable_objects[action][0])
                obj2 = random.choice(partial_applicable_objects[action][1])
                if obj1 == obj2:
                    continue
                else:
                    return action.replace('...', ' '+obj1, 1).replace('...', ' '+obj2), action, [obj1, obj2]

    conjunctions = [', 然后', '的同时']

    forbidden_combinations = [('坐在', '站起来'),    ('站起来', '坐在'),    ('坐在', '休息'),
                              ('休息', '坐在'),    ('站起来', '休息'),    ('休息', '站起来'), ]

    def complex_sentence():
        def check(clause1, clause2, conj):
            if conj == '的同时':
                if (clause1[1], clause2[1]) in forbidden_combinations:
                    return False
                if len(clause1[2]+clause2[2]) > len(set(clause1[2]+clause2[2])):
                    return False
            elif conj == '然后':
                if clause1 == clause2:
                    return False
            return True

        while True:
            clause_num = random.choice([1, 2, 3])
            if clause_num == 1:
                return simple_clause()[0]
            elif clause_num == 2:
                conj = random.choice(conjunctions)
                clause1 = simple_clause()
                clause2 = simple_clause()
                if check(clause1, clause2, conj):
                    return clause1[0] + f' {conj} ' + clause2[0]
                else:
                    continue
            elif clause_num == 3:
                conj1, conj2 = random.choices(conjunctions, k=2)
                clause1 = simple_clause()
                clause2 = simple_clause()
                clause3 = simple_clause()
                if not check(clause1, clause2, conj1):
                    continue
                if not check(clause2, clause3, conj2):
                    continue
                if conj1 == '的同时' and conj2 == '的同时':
                    if not check(clause1, clause3, '的同时'):
                        continue
                return f'{clause1[0]} {conj1} {clause2[0]} {conj2} {clause3[0]}'

    partial_applicable_objects = {}
    for action, objects in applicable_objects.items():
        if object_counts[action] == 0:
            partial_applicable_objects[action] = []
        elif object_counts[action] == 1:
            partial_applicable_objects[action] = []
            for obj in objects:
                if obj in partial_objects:
                    partial_applicable_objects[action].append(obj)
            if len(partial_applicable_objects[action]) == 0:
                partial_applicable_objects.pop(action)
        elif object_counts[action] == 2:
            partial_applicable_objects[action] = [[], []]
            for obj in objects[0]:
                if obj in partial_objects:
                    partial_applicable_objects[action][0].append(obj)
            for obj in objects[1]:
                if obj in partial_objects:
                    partial_applicable_objects[action][1].append(obj)
            if len(partial_applicable_objects[action][0]) == 0 or len(partial_applicable_objects[action][1]) == 0:
                partial_applicable_objects.pop(action)

    partial_actions = []
    for action in partial_applicable_objects.keys():
        partial_actions.append(action)
        # if len(partial_applicable_objects[action]) >= object_counts[action]:
        #     partial_actions.append(action)

    # print(
    #     f'Generating instructions. Current possible actions:{partial_actions}. Current oa pairs:{partial_applicable_objects}')

    instructions = set()
    i = 0
    while len(instructions) < instruction_num:
        i += 1
        if i > 100:
            break
        instruction = complex_sentence()
        instructions.add(instruction)
    return list(instructions)


def eliminate_bounce(timepoints: list, expected_num: int, minimum_bounce_delta:int):
    res = []
    print('Debouncing start...')
    print(f'before debouncing: {timepoints}')
    bounce_delta = minimum_bounce_delta
    while True:
        res.clear()
        res.append(timepoints[0])
        for i in range(len(timepoints)-1):
            if timepoints[i+1] - timepoints[i] >= bounce_delta:
                res.append(timepoints[i+1])
        if len(res) <= expected_num:
            break
        bounce_delta = bounce_delta+1

    print(f'bounce delta: {bounce_delta}')
    print(f'Debouncing ended. Result: {res}')
    return res


# print(generate_action())
# def generate

import bpy
import numpy as np
from mathutils import Vector, Quaternion
from .record import CC_BONE_NAMES


def restore_recording(restore_data, armature_CC):
    # read metadata, human data and object data
    metadata=restore_data['Metadata']

    # set hand scale first
    hand_scale = metadata['hand_scale']
    armature_CC.pose.bones['CC_Base_L_Hand'].scale = (hand_scale,hand_scale,hand_scale)
    armature_CC.pose.bones['CC_Base_R_Hand'].scale = (hand_scale,hand_scale,hand_scale)

    # set bone rotation mode

    maxframe_num=metadata['frame_num']
    fps=int(metadata['fps'])
    
    human_data = restore_data['Human']
    hip_transl = human_data['Hip translation']
    bone_rotations = human_data['rotations']

    object_data = restore_data['Objects']

    
    try:
        from tqdm import tqdm
        use_tqdm=True
        frame_iterator=tqdm(range(maxframe_num))
    except:
        use_tqdm=False
        frame_iterator=range(maxframe_num)
    
    # inserting frames
    for frame in frame_iterator:
        if frame % fps == 0 and not use_tqdm:
            print(f'inserting frame {frame}...')
            
        bpy.context.scene.frame_set(frame)

        # insert human translation
        hip_bone = armature_CC.pose.bones['CC_Base_Hip']
        hip_bone.location = hip_transl[frame]
        hip_bone.keyframe_insert('location')

        # insert human bone rotation
        bone_rotations_frame = bone_rotations[frame]

        for index, bone_name in enumerate(CC_BONE_NAMES):
            bone = armature_CC.pose.bones[bone_name]
            bone.rotation_quaternion = list(bone_rotations_frame[4 * index: 4 * index + 4])

        # deal with the wrist blendskin. copy the y-axis rotation into the forearmTwist01
        for side in ['L','R']:
            hand_bone = armature_CC.pose.bones[f'CC_Base_{side}_Hand']
            rotation = hand_bone.rotation_quaternion.to_euler('YXZ')
            forearm_twist_bone = armature_CC.pose.bones[f'CC_Base_{side}_ForearmTwist02']
            forearm_twist_bone.rotation_mode = 'YXZ'
            forearm_twist_bone.rotation_euler[1] = rotation[1]
            forearm_twist_bone.keyframe_insert('rotation_euler')

        for bone in armature_CC.pose.bones:
            if bone.name in ['CC_Base_L_ForearmTwist02','CC_Base_R_ForearmTwist02']:
                bone.keyframe_insert('rotation_euler')
            elif bone.name in CC_BONE_NAMES:
                bone.keyframe_insert('rotation_quaternion')
            else:
                bone.rotation_quaternion = [1, 0, 0, 0]
                bone.keyframe_insert('rotation_quaternion')     



        # insert object locations and rotations
        for obj_name, obj_pose in object_data.items():
            if np.max(np.abs(obj_pose[frame][:3])) < 0.0001:
                continue
            obj = bpy.data.objects[obj_name]
            obj.location = obj_pose[frame][:3]
            obj.rotation_quaternion = obj_pose[frame][3:]
            obj.keyframe_insert('location')
            obj.keyframe_insert('rotation_quaternion')

    print(f'Restoring done at frame {frame}!')


SMPLX_JOINT_NAMES = [
    'pelvis','left_hip','right_hip','spine1','left_knee','right_knee','spine2','left_ankle','right_ankle','spine3', 'left_foot','right_foot','neck','left_collar','right_collar','head','left_shoulder','right_shoulder','left_elbow', 'right_elbow','left_wrist','right_wrist',
    'jaw','left_eye_smplhf','right_eye_smplhf','left_index1','left_index2','left_index3','left_middle1','left_middle2','left_middle3','left_pinky1','left_pinky2','left_pinky3','left_ring1','left_ring2','left_ring3','left_thumb1','left_thumb2','left_thumb3','right_index1','right_index2','right_index3','right_middle1','right_middle2','right_middle3','right_pinky1','right_pinky2','right_pinky3','right_ring1','right_ring2','right_ring3','right_thumb1','right_thumb2','right_thumb3'
]
NUM_SMPLX_BODYJOINTS = 21
NUM_SMPLX_HANDJOINTS = 15

def set_pose_from_rodrigues(armature, bone_name, rodrigues, rodrigues_reference=None):
    rod = Vector((rodrigues[0], rodrigues[1], rodrigues[2]))
    angle_rad = rod.length
    axis = rod.normalized()

    if armature.pose.bones[bone_name].rotation_mode != 'QUATERNION':
        armature.pose.bones[bone_name].rotation_mode = 'QUATERNION'

    quat = Quaternion(axis, angle_rad)

    if rodrigues_reference is None:
        armature.pose.bones[bone_name].rotation_quaternion = quat
    else:
        # SMPL-X is adding the reference rodrigues rotation to the relaxed hand rodrigues rotation, so we have to do the same here.
        # This means that pose values for relaxed hand model cannot be interpreted as rotations in the local joint coordinate system of the relaxed hand.
        # https://github.com/vchoutas/smplx/blob/f4206853a4746139f61bdcf58571f2cea0cbebad/smplx/body_models.py#L1190
        #   full_pose += self.pose_mean
        rod_reference = Vector((rodrigues_reference[0], rodrigues_reference[1], rodrigues_reference[2]))
        rod_result = rod + rod_reference
        angle_rad_result = rod_result.length
        axis_result = rod_result.normalized()
        quat_result = Quaternion(axis_result, angle_rad_result)
        armature.pose.bones[bone_name].rotation_quaternion = quat_result

        """
        rod_reference = Vector((rodrigues_reference[0], rodrigues_reference[1], rodrigues_reference[2]))
        angle_rad_reference = rod_reference.length
        axis_reference = rod_reference.normalized()
        quat_reference = Quaternion(axis_reference, angle_rad_reference)

        # Rotate first into reference pose and then add the target pose
        armature.pose.bones[bone_name].rotation_quaternion = quat_reference @ quat
        """
    return

def add_smplx_human(gender, betas):
    if (bpy.context.view_layer.objects.active is not None):
            bpy.ops.object.mode_set(mode='OBJECT')

    bpy.context.window_manager.smplx_tool.smplx_gender = gender
    bpy.context.window_manager.smplx_tool.smplx_handpose = "flat"
    bpy.ops.scene.smplx_add_gender()

    mesh_obj = bpy.context.view_layer.objects.active
    armature = mesh_obj.parent

    bpy.ops.object.mode_set(mode='OBJECT')
    for index, beta in enumerate(betas):
        key_block_name = f"Shape{index:03}"

        if key_block_name in mesh_obj.data.shape_keys.key_blocks:
            mesh_obj.data.shape_keys.key_blocks[key_block_name].value = beta
        else:
            print(f"ERROR: No key block for: {key_block_name}")

    bpy.ops.object.smplx_update_joint_locations('EXEC_DEFAULT')
    for bone in armature.pose.bones:
        bone.rotation_mode = 'QUATERNION'
    return armature, mesh_obj

def load_smplx_animation(armature, mesh_obj, data, keyframe_corrective_pose_weights):
    
    num_keyframes = np.array(data["transl"]).reshape(-1,3).shape[0]
    if keyframe_corrective_pose_weights:
        print(f"Adding pose keyframes with keyframed corrective pose weights: {num_keyframes}")
    else:
        print(f"Adding pose keyframes: {num_keyframes}")

    if len(bpy.data.actions) == 0:
        bpy.context.scene.frame_end = num_keyframes
    elif num_keyframes > bpy.context.scene.frame_end:
        bpy.context.scene.frame_end = num_keyframes

    try:
        from tqdm import tqdm
        use_tqdm=True
        frame_iterator=tqdm(range(num_keyframes))
    except:
        use_tqdm=False
        frame_iterator=range(num_keyframes)

    for frame in frame_iterator:
        if (frame % 30) == 0 and not use_tqdm:
            print(f'inserting frame {frame}...')
        bpy.context.scene.frame_set(frame)
        bpy.context.view_layer.update()
        translation = np.array(data["transl"][frame,:]).reshape(3)
        global_orient = np.array(data["global_orient"][frame,:]).reshape(3)
        body_pose = np.array(data["body_pose"][frame,:]).reshape(NUM_SMPLX_BODYJOINTS, 3)
        jaw_pose = np.array(data["jaw_pose"][frame,:]).reshape(3)
        left_hand_pose = np.array(data["left_hand_pose"][frame,:]).reshape(-1, 3)
        right_hand_pose = np.array(data["right_hand_pose"][frame,:]).reshape(-1, 3)
        expression = np.array(data["expression"][frame,:]).reshape(-1).tolist()
        
        set_pose_from_rodrigues(armature, "pelvis", global_orient)
        for index in range(NUM_SMPLX_BODYJOINTS):
            pose_rodrigues = body_pose[index]
            bone_name = SMPLX_JOINT_NAMES[index + 1] # body pose starts with left_hip
            set_pose_from_rodrigues(armature, bone_name, pose_rodrigues)
        set_pose_from_rodrigues(armature, "jaw", jaw_pose)
        start_name_index = 1 + NUM_SMPLX_BODYJOINTS + 3
        for i in range(0, NUM_SMPLX_HANDJOINTS):
            pose_rodrigues = left_hand_pose[i]
            bone_name = SMPLX_JOINT_NAMES[start_name_index + i]
            # pose_relaxed_rodrigues = hand_pose_relaxed[i]
            set_pose_from_rodrigues(armature, bone_name, pose_rodrigues) #, pose_relaxed_rodrigues)

        # Right hand
        start_name_index = 1 + NUM_SMPLX_BODYJOINTS + 3 + NUM_SMPLX_HANDJOINTS
        for i in range(0, NUM_SMPLX_HANDJOINTS):
            pose_rodrigues = right_hand_pose[i]
            bone_name = SMPLX_JOINT_NAMES[start_name_index + i]
            # pose_relaxed_rodrigues = hand_pose_relaxed[NUM_SMPLX_HANDJOINTS + i]
            set_pose_from_rodrigues(armature, bone_name, pose_rodrigues) #, pose_relaxed_rodrigues)
    
        for bone in armature.pose.bones:
            bone.keyframe_insert('rotation_quaternion')

        armature.pose.bones['root'].location = translation
        armature.pose.bones['root'].keyframe_insert('location')

        if keyframe_corrective_pose_weights:
            # Calculate corrective poseshape weights for current pose and keyframe them.
            # Note: This significantly increases animation load time and also reduces real-time playback speed in Blender viewport.
            bpy.ops.object.smplx_set_poseshapes('EXEC_DEFAULT')
            for key_block in mesh_obj.data.shape_keys.key_blocks:
                if key_block.name.startswith("Pose"):
                    key_block.keyframe_insert("value", frame=frame)






import bpy

from .character import change_shogun_bone_names



def _retrive_body_params(armature):
    armature.animation_data_clear()
    bpy.ops.object.select_all(action='DESELECT')
    armature.select_set(True)
    bpy.context.view_layer.objects.active = armature
    bpy.ops.object.location_clear()
    bpy.ops.object.rotation_clear()
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
    bpy.context.view_layer.update()
    bpy.ops.object.mode_set(mode='POSE')
    bpy.ops.pose.loc_clear()
    bpy.ops.pose.rot_clear()
    bpy.ops.object.mode_set(mode='OBJECT')

    body_params = {
        'finger_length': 0.07334,
        'palm_length': 0.087,
        'forearm_length': 0.243,
        'upperarm_length': 0.294,

        'shoulder_width': 0.335,
        'upper_body_length': 0.495,

        # 'hip_width': 0.209,
        'thigh_length': 0.442,
        'calf_length': 0.420,

        'foot_width':0.00,
    }  # zzy

    # old_body_params = body_params.copy()

    posebones = armature.pose.bones
    body_params['finger_length'] = (
        posebones['LeftHandMiddle3'].head - posebones['LeftHandMiddle1'].head).length
    body_params['palm_length'] = (
        posebones['LeftHand'].head - posebones['LeftHandMiddle1'].head).length
    body_params['forearm_length'] = (
        posebones['LeftForeArm'].head - posebones['LeftHand'].head).length
    body_params['upperarm_length'] = (
        posebones['LeftArm'].head - posebones['LeftForeArm'].head).length

    body_params['shoulder_width'] = (
        posebones['LeftArm'].head - posebones['RightArm'].head).length
    body_params['upper_body_length'] = abs(
        (posebones['LeftUpLeg'].head - posebones['RightArm'].head)[2])

    # body_params['hip_width'] = (
    #     posebones['LeftUpLeg'].head - posebones['RightUpLeg'].head).length
    body_params['thigh_length'] = (
        posebones['LeftUpLeg'].head - posebones['LeftLeg'].head).length
    body_params['calf_length'] = (
        posebones['LeftLeg'].head - posebones['LeftFoot'].head).length

    body_params['foot_width'] = (
        posebones['LeftFoot'].head - posebones['RightFoot'].head).length
    return body_params


def _calculate_slider_values(body_params):
    results = {
        'Hand Scale': 0,
        'Finger Length': 0,
        'Chest Width': 0,
        'Forearm Length': 0,
        'Upper Arm Length': 0,

        'Chest Height': 0,
        'Hip Length A': 0,

        'Thigh Length': 0,
        'Lower Leg Length': 0,

        'Hip Width A':0,
    }
    # the following code is only suitable for CC3+ Base Male armature
    results['Hand Scale'] = body_params['palm_length'] * 1030.888 - 102.46
    results['Finger Length'] = (body_params['finger_length'] *
                                0.099392 / body_params['palm_length']/0.07993 - 1) * 373.16
    results['Chest Width'] = (body_params['shoulder_width']-0.3666) * 2837.68 / 2

    arm_length = body_params['shoulder_width']/2 + body_params['forearm_length'] + body_params['upperarm_length'] - (0.1870695 + 1.78359e-4 * results['Chest Width'])

    results['Upper Arm Length'] = arm_length * (body_params['upperarm_length']/(body_params['upperarm_length']+body_params['forearm_length'])) * 687.57 - 216.529
    results['Forearm Length'] = arm_length * (body_params['forearm_length']/(body_params['upperarm_length']+body_params['forearm_length'])) * 823.15 - 209.99096
    results['Chest Height'] = (
        body_params['upper_body_length'] * 0.7144 - 0.36610) * 2278.9
    results['Hip Length A'] = (
        body_params['upper_body_length'] * 0.2856 - 0.14633) * 7342.1
    results['Thigh Length'] = (body_params['thigh_length'] - 0.4574) * 449
    results['Lower Leg Length'] = (
        body_params['calf_length'] - 0.46670) * 440.10
    results['Hip Width A'] = (body_params['foot_width'] - 0.156247) * (0.92402) / (body_params['thigh_length']+body_params['calf_length']) * 1250

    for key, value in results.items():
        results[key] = round(value)

    return results


def calculate_and_print_slider_values(armature_shogun):
    change_shogun_bone_names(armature_shogun)
    body_params = _retrive_body_params(armature_shogun)

    print(f'retieving real body parameters of {armature_shogun.name}:')
    for (key,value) in body_params.items():
        print(key,value)
    print()

    slider_values = _calculate_slider_values(body_params)
    print(f'CC slider values of subject {armature_shogun.name}:')
    print('Upper Arm Length',slider_values['Upper Arm Length'])
    print('Forearm Length',slider_values['Forearm Length'])
    print('Hand Scale',slider_values['Hand Scale'])
    print('Finger Length',slider_values['Finger Length'])
    print('Chest Height',slider_values['Chest Height'])
    print('Chest Width',slider_values['Chest Width'])
    print('Hip Length A',slider_values['Hip Length A'])
    # print('Hip Width A',slider_values['Hip Width A'])
    print('Thigh Length',slider_values['Thigh Length'])
    print('Lower Leg Length',slider_values['Lower Leg Length'])
    print('CC slider value calculation done.')
    print()

    return slider_values




    
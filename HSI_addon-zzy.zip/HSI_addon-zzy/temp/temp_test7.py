# copy rotation code


CC_BONE_NAMES = ['CC_Base_Hip', 'CC_Base_Pelvis',
 'CC_Base_Waist', 'CC_Base_Spine01', 'CC_Base_Spine02', 
 'CC_Base_NeckTwist01', 'CC_Base_NeckTwist02', 'CC_Base_Head', 
 'CC_Base_R_Clavicle', 'CC_Base_R_Upperarm', 'CC_Base_R_Forearm', 'CC_Base_R_Hand', 
 'CC_Base_R_Mid1', 'CC_Base_R_Mid2', 'CC_Base_R_Mid3', 'CC_Base_R_Ring1',
  'CC_Base_R_Ring2', 'CC_Base_R_Ring3', 'CC_Base_R_Pinky1', 'CC_Base_R_Pinky2',
   'CC_Base_R_Pinky3', 'CC_Base_R_Index1', 'CC_Base_R_Index2', 'CC_Base_R_Index3',
    'CC_Base_R_Thumb1', 'CC_Base_R_Thumb2', 'CC_Base_R_Thumb3',
                 
    'CC_Base_L_Clavicle', 'CC_Base_L_Upperarm', 'CC_Base_L_Forearm', 'CC_Base_L_Hand', 
    'CC_Base_L_Mid1', 'CC_Base_L_Mid2', 'CC_Base_L_Mid3', 
     'CC_Base_L_Ring1', 'CC_Base_L_Ring2', 'CC_Base_L_Ring3',
      'CC_Base_L_Pinky1', 'CC_Base_L_Pinky2', 'CC_Base_L_Pinky3', 
      'CC_Base_L_Index1', 'CC_Base_L_Index2', 'CC_Base_L_Index3', 'CC_Base_L_Thumb1', 
      'CC_Base_L_Thumb2', 'CC_Base_L_Thumb3', 'CC_Base_R_Thigh', 
      'CC_Base_R_Calf', 'CC_Base_R_Foot', 'CC_Base_R_ToeBase', 'CC_Base_L_Thigh',
       'CC_Base_L_Calf', 'CC_Base_L_Foot', 'CC_Base_L_ToeBase']

def change_shogun_bone_names(armature_shogun):
    """e.g. Shogun armature name:Take002, hip bone name: \'zzy:Hips\' --> 'Hips' """
    posebones_shogun = armature_shogun.pose.bones
    try:
        print('Changing shogun armature bone names...')
        for bone in posebones_shogun:
            bone.name = bone.name[bone.name.index(':')+1:]
    except:
        print('Failed. Probably already changed last run.')
    else:
        print('Success.')


import bpy
from mathutils import Vector,Matrix,Quaternion
import pickle as pkl
source_armature = bpy.data.objects['zzy.004']
target_armature = bpy.data.objects['zzy']

change_shogun_bone_names(source_armature)

with open(r'D:\HSI_addon\hsi_script\trans_mats.pkl','rb') as f:
    trans_mats = pkl.load(f)

for frame in range(1000,1500):
    bpy.context.scene.frame_set(frame)
    for bone_name in source_armature.pose.bones.keys():
        bone = target_armature.pose.bones[bone_name]
        if bone_name in CC_BONE_NAMES:
            source_quat = source_armature.pose.bones[bone_name].rotation_quaternion
            trans_mat = Matrix(trans_mats[bone_name])
            bone.rotation_quaternion = (trans_mat.inverted() @ Quaternion(source_quat).to_matrix() @trans_mat).to_quaternion()
        else:
            bone.rotation_quaternion = [1, 0, 0, 0]
        
        bone.keyframe_insert('rotation_quaternion')
        # bone.keyframe_insert('rotation_quaternion')
    
    print(f'inserting frame {frame}')



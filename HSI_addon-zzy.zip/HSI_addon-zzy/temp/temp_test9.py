import bpy
def _apply_CC_rest_pose(armature):
    for m in armature.children:
        m.select_set(True)
        bpy.context.view_layer.objects.active = m
        bpy.context.object.shape_key_clear()
        for modifier_name in m.modifiers.keys():
            if m.modifiers[modifier_name].type=='ARMATURE':
                bpy.ops.object.modifier_apply(modifier=modifier_name)
    # 选骨骼，进入pose mode确认rest pose
    armature.select_set(True)
    bpy.ops.object.select_all(action='DESELECT')
    armature.select_set(True)
    bpy.context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode='POSE')
    bpy.ops.pose.armature_apply(selected=False)
    bpy.ops.object.mode_set(mode='OBJECT')

    # 再选mesh，加上modifier
    armature.select_set(True)
    for m in armature.children:
        m.select_set(True)
        bpy.context.view_layer.objects.active = m
        bpy.ops.object.modifier_add(type='ARMATURE')
        m.modifiers['Armature'].object = armature
        bpy.context.object.shape_key_add()


_apply_CC_rest_pose(bpy.data.objects['basemale'])

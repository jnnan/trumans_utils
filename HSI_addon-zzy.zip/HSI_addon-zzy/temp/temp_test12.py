
import bpy
print(bpy.data.filepath)



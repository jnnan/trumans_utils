
import pickle as pkl
import bpy
from mathutils import Matrix,Vector
# D:\YourTsinghua\2022Summer\HumanSceneJointRepresentation\HSI_addon\2022-10-19@15-06-52.pkl
with open(r"D:\HSI\RecordingStorage\2022-11-10@23-36-26.pkl",'rb') as f:
    data=pkl.load(f)

print(0)


armature=bpy.data.objects['zzy.001']
posebones=armature.pose.bones
bpy.context.view_layer.update()
def dfs(bone):
    for child_bone in bone.children:
        if child_bone.name not in  data['Metadata']['static_shift'].keys():
            continue
        static_rot, static_transl = data['Metadata']['static_shift'][child_bone.name]
        trans_mat = Matrix(static_rot).to_4x4()
        trans_mat.translation = static_transl/1000.
        child_bone.matrix = bone.matrix @ trans_mat
        bpy.context.view_layer.update()
        dfs(child_bone)

bpy.context.view_layer.update()
dfs(posebones['CC_Base_Hip'])

print('finished')
# for segment, (static_mat, static_transl) in data['Metadata']['static_shift'].items():
#     if segment=='Hips':
#         continue
#     else:
#         bone=posebones[segment]
#         parent=bone.parent
#         print(bone.name,static_transl/1000)
#         rot=Matrix(static_mat).inverted()
#         bone.rotation_quaternion=rot.to_quaternion()
#         # bone.location = -( parent.matrix.to_3x3().inverted()@(bone.head-parent.head))


# for segment, (static_mat, static_transl) in data['Metadata']['static_shift'].items():
#     posebones[segment].location=-posebones[segment]

# for segment, (static_mat, static_transl) in data['Metadata']['static_shift'].items():
#     if segment=='Hips':
#         continue
#     # if 'Shoulder' not in segment:
#     #     continue
#     static_transl/=1000
#     # static_transl = (static_transl[0] if static_transl[0]>1e-3 else 0,static_transl[1] if static_transl[1]>1e-3 else 0,static_transl[2] if static_transl[2]>1e-3 else 0)
    
#     # rot=Matrix(static_mat).inverted()
#     # transl=rot@Vector(static_transl)
#     # posebones[segment].rotation_quaternion=rot.to_quaternion()
#     # print(f'{segment}:{static_transl}')
#     # print(static_mat)
#     # posebones[segment].location=transl 
#     # posebones[segment].rotation_quaternion=rot.to_quaternion()
#     posebones[segment].location=static_mat
#     # mat_world=posebones[segment].parent.matrix.to_3x3()
#     # local_loc=mat_world.inverted()@(posebones[segment].head - posebones[segment].parent.head )
#     # print(local_loc)
    # posebones[segment].location=transl - local_loc

    # posebones[segment].location=static_transl
    # if segment!='Hips':
    #     posebones[segment].location= rot@(Vector(static_transl - (posebones[segment].head - posebones[segment].parent.head)))



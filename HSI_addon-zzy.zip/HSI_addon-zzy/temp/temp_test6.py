


import pickle as pkl
import bpy
import numpy as np


def _change_shogun_bone_names(armature_shogun):
    """e.g. Shogun armature name:Take002, hip bone name: \'zzy:Hips\' --> 'Hips' """
    posebones_shogun = armature_shogun.pose.bones
    try:
        print('Changing shogun armature bone names...')
        for bone in posebones_shogun:
            bone.name = bone.name[bone.name.index(':')+1 : ]
    except:
        print('Failed. Probably already changed last run.')
    else:
        print('Success.')

CC_BONE_NAMES = ['CC_Base_Hip',
 'CC_Base_Waist', 'CC_Base_Spine01', 'CC_Base_Spine02', 
 'CC_Base_NeckTwist01', 'CC_Base_NeckTwist02', 'CC_Base_Head', 
 'CC_Base_R_Clavicle', 'CC_Base_R_Upperarm', 'CC_Base_R_Forearm', 'CC_Base_R_Hand', 
 'CC_Base_R_Mid1', 'CC_Base_R_Mid2', 'CC_Base_R_Mid3', 'CC_Base_R_Ring1',
  'CC_Base_R_Ring2', 'CC_Base_R_Ring3', 'CC_Base_R_Pinky1', 'CC_Base_R_Pinky2',
   'CC_Base_R_Pinky3', 'CC_Base_R_Index1', 'CC_Base_R_Index2', 'CC_Base_R_Index3',
    'CC_Base_R_Thumb1', 'CC_Base_R_Thumb2', 'CC_Base_R_Thumb3',
                 
    'CC_Base_L_Clavicle', 'CC_Base_L_Upperarm', 'CC_Base_L_Forearm', 'CC_Base_L_Hand', 
    'CC_Base_L_Mid1', 'CC_Base_L_Mid2', 'CC_Base_L_Mid3', 
     'CC_Base_L_Ring1', 'CC_Base_L_Ring2', 'CC_Base_L_Ring3',
      'CC_Base_L_Pinky1', 'CC_Base_L_Pinky2', 'CC_Base_L_Pinky3', 
      'CC_Base_L_Index1', 'CC_Base_L_Index2', 'CC_Base_L_Index3', 'CC_Base_L_Thumb1', 
      'CC_Base_L_Thumb2', 'CC_Base_L_Thumb3', 'CC_Base_R_Thigh', 
      'CC_Base_R_Calf', 'CC_Base_R_Foot', 'CC_Base_R_ToeBase', 'CC_Base_L_Thigh',
       'CC_Base_L_Calf', 'CC_Base_L_Foot', 'CC_Base_L_ToeBase']


armature_CC = bpy.data.objects['zzy.002']
armature_shogun = bpy.data.objects['zzy.003']
_change_shogun_bone_names(armature_shogun)

posebones_CC = armature_CC.pose.bones
posebones_shogun = armature_shogun.pose.bones

trans_mats={}
trans_mats_np={}
for bone in CC_BONE_NAMES:
    trans_mats[bone] = posebones_CC[bone].matrix.to_3x3().inverted() @ posebones_shogun[bone].matrix.to_3x3()
    trans_mats_np[bone] = np.array(trans_mats[bone])

with open(r'D:\HSI_addon\hsi_script\trans_mats.pkl','wb') as f:
    pkl.dump(trans_mats_np,f)
print(trans_mats_np)

# with open(r'D:\HSI_addon\hsi_script\trans_mats.pkl','rb') as f:
#     data = pkl.load(f)

print(0)



import bpy
from mathutils import Matrix,Quaternion,Euler,Vector

def import_shogun_fbx_post(filepath:str):
    bpy.ops.object.select_all(action='DESELECT')
    
    bpy.ops.import_scene.fbx(filepath=filepath)
    # print('importing done')
    armature_shogun = None
    for obj in bpy.context.selected_objects:
        # seems that the only way to tell which armature is the human is to exam 
        # the number of the bones, hope there won't be an object that has 73 bones
        if obj.type=='ARMATURE' and len(obj.pose.bones)==73:
            armature_shogun=obj
            armature_shogun.select_set(False)
            print('found shogun armature')
    if not armature_shogun:
        print('A shogun armature with 73 bones not found!Probably wrong model!')
    bpy.ops.object.delete()

    armature_shogun.select_set(True)
    bpy.context.view_layer.objects.active=armature_shogun
    armature_shogun.animation_data_clear()

    bpy.ops.object.rotation_clear()
    bpy.ops.object.location_clear()
    
    bpy.ops.object.posemode_toggle()
    bpy.ops.pose.rot_clear()
    bpy.ops.pose.loc_clear()
    bpy.ops.object.posemode_toggle()
    
    bpy.ops.object.transform_apply()
    return armature_shogun

def import_shogun_fbx(filepath:str):
    bpy.ops.import_scene.fbx(filepath=filepath)
    for obj in bpy.context.selected_objects:
        if obj.type=='MESH':
            obj.select_set(True)
        else:
            armature_shogun=obj
            obj.select_set(False)
    bpy.ops.object.delete()

    armature_shogun.select_set(True)
    bpy.context.view_layer.objects.active=armature_shogun
    bpy.ops.object.transform_apply()
    return armature_shogun

def import_CC4_fbx(filepath:str, physics_mode='OFF'):
    # CC/iClone addon needed here

    bpy.context.scene.CC3ImportProps.physics_mode=physics_mode

    bpy.ops.cc3.importer(filepath=filepath,param='IMPORT',use_anim=False)

    armature_CC = None
    for obj in bpy.context.selected_objects:
        if obj.type=='ARMATURE':
            armature_CC=obj
        else:
            obj.select_set(False)
    
    bpy.context.view_layer.objects.active = armature_CC
    bpy.ops.object.transform_apply()
    return armature_CC

def remove_CC4_character():
    bpy.ops.cc3.importer(param='DELETE_CHARACTER')
    for obj in bpy.data.objects:
        if 'Collider' in obj.name and obj.parent==None and 'CC' in obj.data.name:
            bpy.ops.object.select_all(action='DESELECT')
            obj.hide_set(False)
            # bpy.context.view_layer.update()
            obj.select_set(True)
            bpy.context.view_layer.objects.active=obj
            bpy.ops.object.delete()

def _apply_CC_rest_pose(armature):
    for m in armature.children:
        m.select_set(True)
        bpy.context.view_layer.objects.active = m
        bpy.context.object.shape_key_clear()
        for modifier_name in m.modifiers.keys():
            if m.modifiers[modifier_name].type=='ARMATURE':
                bpy.ops.object.modifier_apply(modifier=modifier_name)
    # 选骨骼，进入pose mode确认rest pose
    armature.select_set(True)
    bpy.ops.object.select_all(action='DESELECT')
    armature.select_set(True)
    bpy.context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode='POSE')
    bpy.ops.pose.armature_apply(selected=False)
    bpy.ops.object.mode_set(mode='OBJECT')

    # 再选mesh，加上modifier
    armature.select_set(True)
    for m in armature.children:
        m.select_set(True)
        bpy.context.view_layer.objects.active = m
        bpy.ops.object.modifier_add(type='ARMATURE')
        m.modifiers['Armature'].object = armature
        bpy.context.object.shape_key_add()

def change_shogun_bone_names(armature_shogun):
    """e.g. Shogun armature name:Take002, hip bone name: \'zzy:Hips\' --> 'Hips' """
    posebones_shogun = armature_shogun.pose.bones
    try:
        print('Changing shogun armature bone names...')
        for bone in posebones_shogun:
            bone.name = bone.name[bone.name.index(':')+1:]
    except:
        print('Failed. Probably already changed last run.')
    else:
        print('Success.')


def _adjust_shoulder(armature):
    posebones=armature.pose.bones
    # right shoulder
    right_shoulder = posebones['CC_Base_R_Clavicle']
    v_original = right_shoulder.vector
    v_target = v_original.copy()
    v_target[1] = 0
    # print(v_original.angle(v_target))
    trans_mat= Matrix.Rotation(v_original.angle(v_target),3,v_original.cross(v_target)) 
    trans_mat = right_shoulder.matrix.to_3x3().inverted()@trans_mat@right_shoulder.matrix.to_3x3()
    right_shoulder.rotation_mode='QUATERNION'
    right_shoulder.rotation_quaternion=trans_mat.to_quaternion()

    # left shoulder
    left_shoulder = posebones['CC_Base_L_Clavicle']
    v_original = left_shoulder.vector
    v_target = v_original.copy()
    v_target[1] = 0
    trans_mat= Matrix.Rotation(v_original.angle(v_target),3,v_original.cross(v_target)) 
    trans_mat = left_shoulder.matrix.to_3x3().inverted()@trans_mat@left_shoulder.matrix.to_3x3()
    left_shoulder.rotation_mode='QUATERNION'
    left_shoulder.rotation_quaternion=trans_mat.to_quaternion()
    bpy.context.view_layer.update()

def _adjust_hand(armature_CC,armature_shogun):
    posebones_CC = armature_CC.pose.bones
    posebones_shogun = armature_shogun.pose.bones
    hand_right = posebones_CC['CC_Base_R_Hand']
    shogun_mid_vector =( posebones_shogun['RightHandMiddle3'].head - posebones_shogun['RightHand'].head)
    cc_mid_vector = (posebones_CC['CC_Base_R_Mid3'].head - hand_right.head)
    print(shogun_mid_vector)
    print(cc_mid_vector)
    axis=cc_mid_vector.cross(shogun_mid_vector)
    angle=cc_mid_vector.angle(shogun_mid_vector)
    rot_mat=Matrix.Rotation(angle,3,axis)
    world_matrix=posebones_CC['CC_Base_R_Hand'].matrix.to_3x3()
    rot_quaternion= (world_matrix.inverted()@rot_mat@world_matrix).to_quaternion()
    hand_right.rotation_quaternion=rot_quaternion
    # scale = shogun_mid_vector.length/cc_mid_vector.length * 0.95
    # hand_right.scale=(scale,scale,scale)

    # left hand
    hand_left = posebones_CC['CC_Base_L_Hand']
    shogun_mid_vector =( posebones_shogun['LeftHand'].head - posebones_shogun['LeftHandMiddle3'].head)
    cc_mid_vector = (hand_left.head - posebones_CC['CC_Base_L_Mid3'].head)
    axis=cc_mid_vector.cross(shogun_mid_vector)
    angle=cc_mid_vector.angle(shogun_mid_vector)
    rot_mat=Matrix.Rotation(angle,3,axis)
    world_matrix=posebones_CC['CC_Base_L_Hand'].matrix.to_3x3()
    rot_quaternion= (world_matrix.inverted()@rot_mat@world_matrix).to_quaternion()
    hand_left.rotation_quaternion=rot_quaternion
    # scale = shogun_mid_vector.length/cc_mid_vector.length * 0.95
    # hand_left.scale=(scale,scale,scale)
    lefthand_bones=['CC_Base_L_Hand',
     'CC_Base_L_Pinky1', 'CC_Base_L_Pinky2', 'CC_Base_L_Pinky3', 'CC_Base_L_Ring1', 
    'CC_Base_L_Ring2', 'CC_Base_L_Ring3', 'CC_Base_L_Mid1', 'CC_Base_L_Mid2', 'CC_Base_L_Mid3', 'CC_Base_L_Index1', 
    'CC_Base_L_Index2', 'CC_Base_L_Index3', 'CC_Base_L_Thumb1', 'CC_Base_L_Thumb2', 'CC_Base_L_Thumb3',]
    quaternions_L=[[0.9979872703552246, -0.06327740848064423, 0.002733170287683606, 0.0030627641826868057],#[0.9504157900810242, -0.1316140592098236, 0.2603560984134674, -0.10771387815475464],
                [0.9966228604316711 ,-0.08127740770578384 ,2.907436282839626e-05, -0.011698123998939991],
                [1.0,0.0, 0.0,0.0],
                [1.0,0.0, 0.0,0.0],
                [0.9999842047691345, -0.005586417391896248, 1.0019186447607353e-05, -0.0008043819689191878],
                [1.0, 0.0 ,0.0 ,0.0],
                [1.0, 0.0 ,0.0 ,0.0],
                [1.0, 0.0 ,0.0 ,0.0],
                [1.0, 0.0 ,0.0 ,0.0],
                [1.0, 0.0 ,0.0 ,0.0],
                [0.9998961687088013 ,0.01428158674389124, 0.00014604476746171713, 0.0019383052131161094],
                [1.0, 0.0, 0.0 ,0.0],
                [1.0, 0.0, 0.0, 0.0],
                [0.9818609356880188, -0.1722450852394104, 0.07869839668273926, -0.009367064572870731],
                [0.9526671171188354 ,0.087397500872612, -0.2911374866962433, 0.005112813785672188],
                [1.0, 0.0, 0.0 ,0.0]]
    quaternions_R=[[0.9979326128959656, -0.06412996351718903, -0.0027720134239643812, -0.0031840382143855095],
                [0.9966222643852234,-0.08128594607114792,-3.29270405927673e-05,0.01169199962168932],
                [1.0,-8.772050932748243e-06,4.429530690686079e-06,6.876572297187522e-05],
                [1.0,2.9612354410346597e-05,-7.2686016210354865e-06,3.702857065945864e-05],
                [0.999984085559845,-0.005589426029473543,-1.6348651115549728e-05,0.000791875587310642],
                [1.0,1.662875547481235e-05,9.637609764467925e-06,-2.8446218493627384e-05],
                [1.0,-8.050079486565664e-06,-3.503992502373876e-06,0.00011613816604949534],
                [1.0,-3.969253725699673e-07,-5.410061021393631e-06,2.9979053579154424e-05],
                [1.0,1.2761422112816945e-05,3.871964054269483e-06,-4.6364621084649116e-05],
                [1.0,-5.254125426290557e-05,-3.6558510601025773e-06,0.0001460871717426926],
                [0.9998956918716431,0.014297597110271454,-0.00015313856420107186,-0.002046008361503482],
                [0.9999998807907104,-0.0003723816480487585,3.726368049683515e-06,-0.0003448901989031583],
                [0.9999996423721313,0.0005913600907661021,4.878196705249138e-05,0.0007511146832257509],
                [0.981866717338562,-0.17221233248710632,-0.07869464159011841,0.009375492110848427],
                [0.9526734948158264,0.08735395967960358,0.29112958908081055,-0.005108204670250416],
                [1.0,7.591024041175842e-05,-2.3515895009040833e-06,0.00020456688071135432]]
    for index,bone in enumerate(lefthand_bones):
        if index==0:
            continue
        posebones_CC[bone].rotation_mode='QUATERNION'
        posebones_CC[bone].rotation_quaternion = quaternions_L[index]
        bone_R=bone.replace('_L_','_R_')
        posebones_CC[bone_R].rotation_mode='QUATERNION'
        posebones_CC[bone_R].rotation_quaternion = quaternions_R[index]
        # bpy.context.view_layer.update()
    # _apply_CC_rest_pose(armature)
    bpy.context.view_layer.update()

def _adjust_arm(armature):
    posebones=armature.pose.bones
    # right arm
    right_arm = posebones['CC_Base_R_Upperarm']
    v_original = right_arm.vector
    v_target = v_original.copy()
    v_target[1] = 0
    v_target[2] = 0
    trans_mat= Matrix.Rotation(v_original.angle(v_target),3,v_original.cross(v_target)) 
    trans_mat = right_arm.matrix.to_3x3().inverted()@trans_mat@right_arm.matrix.to_3x3()
    right_arm.rotation_mode='QUATERNION'
    right_arm.rotation_quaternion=trans_mat.to_quaternion()
    bpy.context.view_layer.update()

    # right forearm
    right_forearm = posebones['CC_Base_R_Forearm']
    v_original = right_forearm.vector
    v_target = v_original.copy()
    v_target[1] = 0
    v_target[2] = 0
    trans_mat= Matrix.Rotation(v_original.angle(v_target),3,v_original.cross(v_target)) 
    trans_mat = right_forearm.matrix.to_3x3().inverted()@trans_mat@right_forearm.matrix.to_3x3()
    right_forearm.rotation_mode='QUATERNION'
    right_forearm.rotation_quaternion=trans_mat.to_quaternion()
    bpy.context.view_layer.update()

    # left arm
    left_arm = posebones['CC_Base_L_Upperarm']
    v_original = left_arm.vector
    v_target = v_original.copy()
    v_target[1] = 0
    v_target[2] = 0
    trans_mat= Matrix.Rotation(v_original.angle(v_target),3,v_original.cross(v_target)) 
    trans_mat = left_arm.matrix.to_3x3().inverted()@trans_mat@left_arm.matrix.to_3x3()
    left_arm.rotation_mode='QUATERNION'
    left_arm.rotation_quaternion=trans_mat.to_quaternion()
    bpy.context.view_layer.update()

    # left forearm
    left_forearm = posebones['CC_Base_L_Forearm']
    v_original = left_forearm.vector
    v_target = v_original.copy()
    v_target[1] = 0
    v_target[2] = 0
    trans_mat= Matrix.Rotation(v_original.angle(v_target),3,v_original.cross(v_target)) 
    trans_mat = left_forearm.matrix.to_3x3().inverted()@trans_mat@left_forearm.matrix.to_3x3()
    left_forearm.rotation_mode='QUATERNION'
    left_forearm.rotation_quaternion=trans_mat.to_quaternion()
    bpy.context.view_layer.update()

def _adjust_spine(armature_CC):
    posebones = armature_CC.pose.bones
    world_matrix_left_thigh = posebones['CC_Base_L_Thigh'].matrix.copy()
    world_matrix_right_thigh = posebones['CC_Base_R_Thigh'].matrix.copy()
    pelvis = posebones['CC_Base_Pelvis']
    
    v_original = pelvis.vector
    v_target = v_original.copy()
    v_target[0] = 0
    v_target[1] = 0
    # v_target[2] = 1
    trans_mat= Matrix.Rotation(v_original.angle(v_target),3,v_original.cross(v_target)) 
    trans_mat = pelvis.matrix.to_3x3().inverted()@trans_mat@pelvis.matrix.to_3x3()
    pelvis.rotation_mode='QUATERNION'
    pelvis.rotation_quaternion=trans_mat.to_quaternion()
    bpy.context.view_layer.update()

    posebones['CC_Base_L_Thigh'].matrix = world_matrix_left_thigh
    posebones['CC_Base_R_Thigh'].matrix = world_matrix_right_thigh 
    
    # warning: this is a hyperparameter hidden here
    # meaning that the waist mesh moves DRIFT towards the front side
    DRIFT = 0.01
    # target_position = posebones['CC_Base_Waist'].matrix.translation + Vector((0,DRIFT,0))
    posebones['CC_Base_Waist'].location = posebones['CC_Base_Waist'].matrix.to_3x3().inverted() @ Vector((0,DRIFT,0))
    # posebones['CC_Base_Spine01'].location = posebones['CC_Base_Spine01'].matrix.to_3x3().inverted() @ Vector((0,-DRIFT*2/3,0))
    posebones['CC_Base_Spine02'].location = posebones['CC_Base_Spine02'].matrix.to_3x3().inverted() @ Vector((0,-DRIFT,0))
    bpy.context.view_layer.update()
    # posebones['CC_Base_Spine01'].location = (0,0,-DRIFT)
    # posebones['CC_Base_Spine02'].location = (0,0,-DRIFT)


def _init_armatures(armature_CC,armature_shogun):
    armature_shogun.rotation_euler[2]=3.1415926
    bpy.ops.object.select_all(action='DESELECT')
    armature_shogun.select_set(True)
    bpy.context.view_layer.objects.active = armature_shogun
    bpy.ops.object.transform_apply()
    bpy.ops.object.select_all(action='DESELECT')

def _scale_100(armature_CC):
    armature_CC.scale = (100,100,100)
    bpy.ops.object.select_all(action='DESELECT')
    armature_CC.select_set(True)
    bpy.context.view_layer.objects.active = armature_CC
    bpy.ops.object.transform_apply()
    armature_CC.scale = (0.01,0.01,0.01)
    bpy.context.view_layer.update()

def calibrate(armature_CC,armature_shogun):
    print('changing CC arm and hand rotations to get T-pose and best hand poses...')
    change_shogun_bone_names(armature_shogun)
    _init_armatures(armature_CC,armature_shogun)
    _adjust_shoulder(armature_CC)
    _adjust_arm(armature_CC)
    _adjust_hand(armature_CC,armature_shogun)
    _adjust_spine(armature_CC)
    _apply_CC_rest_pose(armature_CC)
    _scale_100(armature_CC)
    print('CC armature rotation changed and rest pose applied...')

armature_CC = bpy.data.objects['zzy.001']
armature_shogun = bpy.data.objects['zzy_10fingures_VR']

calibrate(armature_CC, armature_shogun)


# _adjust_spine(armature_CC)










def eliminate_bounce(timepoints:list, expected_num:int):
    res = []
    print(f'Debouncing start. Before debouncing: {timepoints}')
    bounce_delta = 1
    while True:
        res.clear()
        res.append(timepoints[0])
        for i in range(len(timepoints)-1):
            if timepoints[i+1] - timepoints[i] >= bounce_delta:
                res.append(timepoints[i+1])
        if len(res)<=expected_num:
            break
        bounce_delta=bounce_delta+1
    print(f'Debouncing ended. Bounce delta: {bounce_delta}. Result: {res}')
    return res



# 555

eliminate_bounce([121, 125, 125, 145, 148, 148, 159, 162, 162, 170, 173, 173], 4)
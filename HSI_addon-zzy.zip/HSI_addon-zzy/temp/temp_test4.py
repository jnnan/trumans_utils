import bpy





obj_source=bpy.data.objects['Basic_T_shirts.001']

not_to_touch=['CC_Base_Spine01','CC_Base_Spine03']
to_touch={}
obj_dest=bpy.data.objects['Basic_T_shirts']

for vertex_group in obj_dest.vertex_groups:
    if vertex_group.name in not_to_touch:
        continue
    else:
        # to_touch.append(vertex_group.name)
        obj_dest.vertex_groups.remove(vertex_group)
        # obj_dest.vertex_groups.new(name=name)

for vertex_group in obj_source.vertex_groups:
    if vertex_group.name in not_to_touch:
        continue
    else:
        to_touch[vertex_group.index]=vertex_group.name

for name in to_touch.values():
    obj_dest.vertex_groups.new(name=name)

v_index_g_indices_list = [[v.index, [g.group for g in v.groups]] for v in obj_source.data.vertices]

for v_index_g_indices in v_index_g_indices_list:
    v_index=v_index_g_indices[0]
    for g in v_index_g_indices[1]:
        try:
            group_name=to_touch[g]
        except:
            continue
        obj_dest.vertex_groups[group_name].add([v_index], obj_source.vertex_groups[group_name].weight(v_index), 'REPLACE')

    






































a ={'hi'}

print(type(a))

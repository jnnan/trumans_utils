




import bpy
import sys

try:
    sys.path.append(r'D:\HSI_addon')
    filepath = bpy.path.abspath(r"D:\HSI_addon\__init__.py")
    exec(compile(open(filepath).read(), filepath, 'exec'))
except:
    sys.path.append(r'D:\YourTsinghua\2022Summer\HumanSceneJointRepresentation\HSI_addon')
    filepath = bpy.path.abspath(r"D:\YourTsinghua\2022Summer\HumanSceneJointRepresentation\HSI_addon\__init__.py")
    exec(compile(open(filepath).read(), filepath, 'exec'))   



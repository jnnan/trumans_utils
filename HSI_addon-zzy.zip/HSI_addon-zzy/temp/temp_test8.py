





import bpy
from mathutils import Vector
CC_BONE_NAMES = ['CC_Base_Hip','CC_Base_Pelvis',
 'CC_Base_Waist', 'CC_Base_Spine01', 'CC_Base_Spine02', 
 'CC_Base_NeckTwist01', 'CC_Base_NeckTwist02', 'CC_Base_Head', 
 'CC_Base_R_Clavicle', 'CC_Base_R_Upperarm', 'CC_Base_R_Forearm', 'CC_Base_R_Hand', 
 'CC_Base_R_Mid1', 'CC_Base_R_Mid2', 'CC_Base_R_Mid3', 'CC_Base_R_Ring1',
  'CC_Base_R_Ring2', 'CC_Base_R_Ring3', 'CC_Base_R_Pinky1', 'CC_Base_R_Pinky2',
   'CC_Base_R_Pinky3', 'CC_Base_R_Index1', 'CC_Base_R_Index2', 'CC_Base_R_Index3',
    'CC_Base_R_Thumb1', 'CC_Base_R_Thumb2', 'CC_Base_R_Thumb3',
                 
    'CC_Base_L_Clavicle', 'CC_Base_L_Upperarm', 'CC_Base_L_Forearm', 'CC_Base_L_Hand', 
    'CC_Base_L_Mid1', 'CC_Base_L_Mid2', 'CC_Base_L_Mid3', 
     'CC_Base_L_Ring1', 'CC_Base_L_Ring2', 'CC_Base_L_Ring3',
      'CC_Base_L_Pinky1', 'CC_Base_L_Pinky2', 'CC_Base_L_Pinky3', 
      'CC_Base_L_Index1', 'CC_Base_L_Index2', 'CC_Base_L_Index3', 'CC_Base_L_Thumb1', 
      'CC_Base_L_Thumb2', 'CC_Base_L_Thumb3', 'CC_Base_R_Thigh', 
      'CC_Base_R_Calf', 'CC_Base_R_Foot', 'CC_Base_R_ToeBase', 'CC_Base_L_Thigh',
       'CC_Base_L_Calf', 'CC_Base_L_Foot', 'CC_Base_L_ToeBase']

def change_shogun_bone_names(armature_shogun):
    """e.g. Shogun armature name:Take002, hip bone name: \'zzy:Hips\' --> 'Hips' """
    posebones_shogun = armature_shogun.pose.bones
    try:
        print('Changing shogun armature bone names...')
        for bone in posebones_shogun:
            bone.name = bone.name[bone.name.index(':')+1:]
    except:
        print('Failed. Probably already changed last run.')
    else:
        print('Success.')


source_armature = bpy.data.objects['zzy.008']
target_armature = bpy.data.objects['zzy']
change_shogun_bone_names(source_armature)
trans_mats={}

for bone_name in CC_BONE_NAMES:
    target_bone = target_armature.pose.bones[bone_name]
    source_bone = source_armature.pose.bones[bone_name]
    if source_bone.parent:
        w1 = source_bone.matrix.to_3x3()
        w2 = target_bone.matrix.to_3x3()
        w3 = source_bone.parent.matrix.to_3x3()
        w4 = target_bone.parent.matrix.to_3x3()
        trans_mats[bone_name] = w2.inverted() @ w4 @ w3.inverted() @ w1
    else:
        w1 = source_bone.matrix.to_3x3()
        w2 = target_bone.matrix.to_3x3()
        trans_mats[bone_name] = w2.inverted() @ w1

trans_mats_np = {}
import numpy as np
for (key,value) in trans_mats.items():
    trans_mats_np[key] = np.array(value)

import pickle as pkl
with open(r'D:\HSI_addon\hsi_script\trans_mats.pkl','wb') as f:
    pkl.dump(trans_mats_np,f)

source_armature = bpy.data.objects['zzy.009']
change_shogun_bone_names(source_armature)

for frame in range(300,800):
    bpy.context.scene.frame_set(frame)
    loc = source_armature.pose.bones['CC_Base_Hip'].location
    target_armature.pose.bones['CC_Base_Hip'].location = (loc[0],loc[2],-loc[1])
    target_armature.pose.bones['CC_Base_Hip'].keyframe_insert('location')
    
    
    for bone_name in CC_BONE_NAMES:
        
        target_armature.pose.bones[bone_name].rotation_mode = 'QUATERNION'
        target_armature.pose.bones[bone_name].rotation_quaternion = (trans_mats[bone_name] @ source_armature.pose.bones[bone_name].rotation_quaternion.to_matrix() ).to_quaternion()
    
    for bone in target_armature.pose.bones:
        if bone.name not in CC_BONE_NAMES:
            bone.rotation_quaternion = [1, 0, 0, 0]
        bone.keyframe_insert('rotation_quaternion')
    print(f'Restoring done at frame {frame}!')










import bpy
from mathutils import Matrix,Quaternion,Euler,Vector

def import_shogun_fbx(filepath:str):
    bpy.ops.object.select_all(action='DESELECT')
    
    bpy.ops.import_scene.fbx(filepath=filepath)

    armature_shogun = None
    for obj in bpy.context.selected_objects:
        # seems that only way to tell which armature is the human is to exam 
        # the number of the bones, hope there won't be an object that has 73 bones
        if obj.type=='ARMATURE' and len(obj.pose.bones)==73 :
            armature_shogun=obj
            armature_shogun.select_set(False)
    bpy.ops.object.delete()

    armature_shogun.select_set(True)
    bpy.context.view_layer.objects.active=armature_shogun

    bpy.ops.object.rotation_clear()
    bpy.ops.object.location_clear()
    
    bpy.ops.object.posemode_toggle()
    bpy.ops.pose.rot_clear()
    bpy.ops.pose.loc_clear()
    bpy.ops.object.posemode_toggle()
    
    bpy.ops.object.transform_apply()
    return armature_shogun

def import_CC4_fbx(filepath:str=r'D:\YourTsinghua\2022Summer\HumanSceneJointRepresentation\cc4_character\kevin.Fbx',physics_mode='OFF'):
    # CC/iClone addon needed here

    bpy.context.scene.CC3ImportProps.physics_mode=physics_mode

    bpy.ops.cc3.importer(filepath=filepath,param='IMPORT',use_anim=False)

    armature_CC = None
    for obj in bpy.context.selected_objects:
        if obj.type=='ARMATURE':
            armature_CC=obj
        else:
            obj.select_set(False)
    
    bpy.context.view_layer.objects.active = armature_CC
    bpy.ops.object.transform_apply()
    return armature_CC

def remove_CC4_character():
    bpy.ops.cc3.importer(param='DELETE_CHARACTER')
    for obj in bpy.data.objects:
        if 'Collider' in obj.name and obj.parent==None and 'CC' in obj.data.name:
            bpy.ops.object.select_all(action='DESELECT')
            obj.hide_set(False)
            # bpy.context.view_layer.update()
            obj.select_set(True)
            bpy.context.view_layer.objects.active=obj
            bpy.ops.object.delete()




MESH_ANKLE_DELTA = -0.012 # difference between cc mesh and shogun character

BONE_NAMES_SHOGUN = ['Hips', 'Spine', 'Spine1', 'Spine2', 'Spine3', 'Neck', 'Neck1', 'Head', 'HeadEnd', 
    'RightShoulder', 'RightArm', 'RightForeArm', 'RightHand',
    'RightHandMiddle1', 'RightHandMiddle2', 'RightHandMiddle3', 'RightHandMiddle4', 'RightHandRing', 'RightHandRing1', 'RightHandRing2', 'RightHandRing3', 'RightHandRing4', 'RightHandPinky', 'RightHandPinky1', 'RightHandPinky2', 'RightHandPinky3', 'RightHandPinky4', 'RightHandIndex', 'RightHandIndex1', 'RightHandIndex2', 'RightHandIndex3', 'RightHandIndex4', 'RightHandThumb1', 'RightHandThumb2', 'RightHandThumb3', 'RightHandThumb4', 
    'LeftShoulder','LeftArm', 'LeftForeArm', 'LeftHand', 
    'LeftHandMiddle1', 'LeftHandMiddle2', 'LeftHandMiddle3', 'LeftHandMiddle4', 'LeftHandRing', 'LeftHandRing1', 'LeftHandRing2', 'LeftHandRing3', 'LeftHandRing4', 'LeftHandPinky', 'LeftHandPinky1', 'LeftHandPinky2', 'LeftHandPinky3', 'LeftHandPinky4', 'LeftHandIndex', 'LeftHandIndex1', 'LeftHandIndex2', 'LeftHandIndex3', 'LeftHandIndex4', 'LeftHandThumb1', 'LeftHandThumb2', 'LeftHandThumb3', 'LeftHandThumb4', 
    'RightUpLeg', 'RightLeg', 'RightFoot', 'RightToeBase', 'RightToeBaseEnd', 
    'LeftUpLeg', 'LeftLeg', 'LeftFoot', 'LeftToeBase', 'LeftToeBaseEnd']

BONE_NAMES_CC=[
    # hip--spine--head
    'CC_Base_BoneRoot', 'CC_Base_Hip', 'CC_Base_Pelvis', 
    'CC_Base_Waist', 'CC_Base_Spine01', 'CC_Base_Spine02', 'CC_Base_NeckTwist01', 'CC_Base_NeckTwist02', 'CC_Base_Head', 
    
    # left/right leg
    'CC_Base_L_Thigh', 'CC_Base_L_Calf', 'CC_Base_L_Foot', 'CC_Base_L_ToeBaseShareBone', 'CC_Base_L_ToeBase', 'CC_Base_L_PinkyToe1', 'CC_Base_L_RingToe1', 'CC_Base_L_MidToe1', 'CC_Base_L_IndexToe1', 'CC_Base_L_BigToe1', 'CC_Base_L_CalfTwist01', 'CC_Base_L_CalfTwist02', 'CC_Base_L_KneeShareBone', 'CC_Base_L_ThighTwist01', 'CC_Base_L_ThighTwist02', 
    'CC_Base_R_Thigh', 'CC_Base_R_Calf', 'CC_Base_R_KneeShareBone', 'CC_Base_R_Foot', 'CC_Base_R_ToeBase', 'CC_Base_R_BigToe1', 'CC_Base_R_PinkyToe1', 'CC_Base_R_RingToe1', 'CC_Base_R_IndexToe1', 'CC_Base_R_MidToe1', 'CC_Base_R_ToeBaseShareBone', 'CC_Base_R_CalfTwist01', 'CC_Base_R_CalfTwist02', 'CC_Base_R_ThighTwist01', 'CC_Base_R_ThighTwist02', 
    
    # left/right arm and hand
    'CC_Base_L_Clavicle', 'CC_Base_L_Upperarm', 'CC_Base_L_Forearm', 'CC_Base_L_ForearmTwist01', 'CC_Base_L_ForearmTwist02', 'CC_Base_L_ElbowShareBone', 'CC_Base_L_UpperarmTwist01', 'CC_Base_L_UpperarmTwist02', 
    'CC_Base_L_Hand', 'CC_Base_L_Pinky1', 'CC_Base_L_Pinky2', 'CC_Base_L_Pinky3', 'CC_Base_L_Ring1', 'CC_Base_L_Ring2', 'CC_Base_L_Ring3', 'CC_Base_L_Mid1', 'CC_Base_L_Mid2', 'CC_Base_L_Mid3', 'CC_Base_L_Index1', 'CC_Base_L_Index2', 'CC_Base_L_Index3', 'CC_Base_L_Thumb1', 'CC_Base_L_Thumb2', 'CC_Base_L_Thumb3', 
    
    'CC_Base_R_Clavicle', 'CC_Base_R_Upperarm', 'CC_Base_R_Forearm', 'CC_Base_R_ElbowShareBone', 'CC_Base_R_ForearmTwist01', 'CC_Base_R_ForearmTwist02', 'CC_Base_R_UpperarmTwist01', 'CC_Base_R_UpperarmTwist02'
    'CC_Base_R_Hand', 'CC_Base_R_Ring1', 'CC_Base_R_Ring2', 'CC_Base_R_Ring3', 'CC_Base_R_Mid1', 'CC_Base_R_Mid2', 'CC_Base_R_Mid3', 'CC_Base_R_Thumb1', 'CC_Base_R_Thumb2', 'CC_Base_R_Thumb3', 'CC_Base_R_Index1', 'CC_Base_R_Index2', 'CC_Base_R_Index3', 'CC_Base_R_Pinky1', 'CC_Base_R_Pinky2', 'CC_Base_R_Pinky3', 
    
    # useless
    'CC_Base_FacialBone', 'CC_Base_JawRoot', 'CC_Base_Tongue01', 'CC_Base_Tongue02', 'CC_Base_Tongue03', 'CC_Base_Teeth02', 'CC_Base_R_Eye', 'CC_Base_L_Eye', 'CC_Base_UpperJaw', 'CC_Base_Teeth01', 
    'CC_Base_L_RibsTwist', 'CC_Base_L_Breast', 'CC_Base_R_RibsTwist', 'CC_Base_R_Breast', 
    ]

def _apply_CC_rest_pose(armature):

    # armature.select_set(True)
    # bpy.ops.object.select_all(action='DESELECT')
    # armature.select_set(True)
    # bpy.context.view_layer.objects.active = armature
    # bpy.ops.object.mode_set(mode='OBJECT')
    # bpy.ops.object.select_all(action='DESELECT')


    for m in armature.children:
        m.select_set(True)
        bpy.context.view_layer.objects.active = m
        bpy.context.object.shape_key_clear()
        # bpy.context.object.shape_key_add()
        # bpy.ops.object.shape_key_remove(all=True)
        for modifier_name in m.modifiers.keys():
            if m.modifiers[modifier_name].type=='ARMATURE':
                bpy.ops.object.modifier_apply(modifier=modifier_name)
    # 选骨骼，进入pose mode确认rest pose
    armature.select_set(True)
    bpy.ops.object.select_all(action='DESELECT')
    armature.select_set(True)
    bpy.context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode='POSE')
    bpy.ops.pose.armature_apply(selected=False)
    bpy.ops.object.mode_set(mode='OBJECT')

    # 再选mesh，加上modifier
    armature.select_set(True)
    for m in armature.children:
        m.select_set(True)
        bpy.context.view_layer.objects.active = m
        bpy.ops.object.modifier_add(type='ARMATURE')
        m.modifiers['Armature'].object = armature
        bpy.context.object.shape_key_add()

def _adjust_CC_arm_rotations(armature_CC):
    posebones_CC = armature_CC.pose.bones
    #adjust rotations of the arms to get a T-pose
    upperarm_left = posebones_CC['CC_Base_L_Upperarm']
    forearm_left=posebones_CC['CC_Base_L_Forearm']
    target_matrix_L=Matrix(((0,-1,0,0),(0,0,1,0),(-1,0,0,0),(0,0,0,1))).to_3x3()
    rot_quaternion=(upperarm_left.matrix.to_3x3().inverted() @ target_matrix_L).to_quaternion()
    upperarm_left.rotation_quaternion=rot_quaternion
    bpy.context.view_layer.update()
    rot_quaternion=(forearm_left.matrix.to_3x3().inverted() @ target_matrix_L).to_quaternion()
    forearm_left.rotation_quaternion=rot_quaternion
    upperarm_right=posebones_CC['CC_Base_R_Upperarm']
    forearm_right=posebones_CC['CC_Base_R_Forearm']
    target_matrix_R=Matrix(((0,1,0,0),(0,0,1,0),(1,0,0,0),(0,0,0,1))).to_3x3()
    rot_quaternion=(upperarm_right.matrix.to_3x3().inverted() @ target_matrix_R).to_quaternion()
    upperarm_right.rotation_quaternion=rot_quaternion
    bpy.context.view_layer.update()
    rot_quaternion=(forearm_right.matrix.to_3x3().inverted() @ target_matrix_R).to_quaternion()
    forearm_right.rotation_quaternion=rot_quaternion    
    _apply_CC_rest_pose(armature_CC)
    return

def _adjust_CC_arm_lengths(posebones_CC,posebones_shogun):
    # adjust the width of the shoulders first
    clavicle_left=posebones_CC['CC_Base_L_Clavicle']
    clavicle_right=posebones_CC['CC_Base_R_Clavicle']
    width=abs(clavicle_left.tail[0] - clavicle_left.parent.tail[0]) 

    target_width=abs(posebones_shogun['LeftArm'].head[0]-posebones_shogun['LeftShoulder'].head[0])
    scale=target_width/width
    # print('adjusting arm length')
    # print(scale)
    # print(target_width,width)
    # print(clavicle_left.tail,clavicle_left.parent.tail)

    clavicle_left.location[1] = -clavicle_left.head[0] *(1-scale)
    clavicle_left.scale=(scale,scale,scale)
    clavicle_right.location[1] = -clavicle_left.head[0] *(1-scale)
    clavicle_right.scale=(scale,scale,scale)
    bpy.context.view_layer.update()

    # adjust the shoulders to a little bit front
    delta_to_front = -posebones_CC['CC_Base_L_Upperarm'].head[1] + posebones_shogun['RightArm'].head[1]
    posebones_CC['CC_Base_L_Upperarm'].location[2] = delta_to_front
    posebones_CC['CC_Base_R_Upperarm'].location[2] = delta_to_front
    # print(posebones_CC['CC_Base_L_Upperarm'].head[1])
    # print(posebones_shogun['RightArm'].head[1])

    # then adjust the length of the upperarm
    upperarm_left=posebones_CC['CC_Base_L_Upperarm']
    forearm_left=posebones_CC['CC_Base_L_Forearm']
    upperarm_length=abs(upperarm_left.head[0]-forearm_left.head[0])
    target_upperarm_length=abs(posebones_shogun['LeftArm'].head[0]-posebones_shogun['LeftForeArm'].head[0])
    scale=target_upperarm_length/upperarm_length
    upperarm_left.scale=(scale,scale,scale)
    upperarm_right=posebones_CC['CC_Base_R_Upperarm']
    upperarm_right.scale=(scale,scale,scale)
    bpy.context.view_layer.update()

    # then adjust the length of the forearm
    forearm_left=posebones_CC['CC_Base_L_Forearm']
    hand_left=posebones_CC['CC_Base_L_Hand']
    forearm_length=abs(forearm_left.head[0]-hand_left.head[0])
    target_forearm_length=abs(posebones_shogun['LeftForeArm'].head[0]-posebones_shogun['LeftHand'].head[0])
    scale=target_forearm_length/forearm_length
    forearm_left.scale=(scale,scale,scale)
    forearm_right=posebones_CC['CC_Base_R_Forearm']
    forearm_right.scale=(scale,scale,scale)
    bpy.context.view_layer.update()  

    _apply_CC_rest_pose(armature_CC)
    return

def _adjust_CC_hands(posebones_CC,posebones_shogun,armature_CC):
    # adjust the scale and rotation of the hand
    # right hand
    hand_right = posebones_CC['CC_Base_R_Hand']
    shogun_mid_vector =( posebones_shogun['RightHand'].head - posebones_shogun['RightHandMiddle3'].head)
    cc_mid_vector = (hand_right.head - posebones_CC['CC_Base_R_Mid3'].head)
    axis=cc_mid_vector.cross(shogun_mid_vector)
    angle=cc_mid_vector.angle(shogun_mid_vector)
    rot_mat=Matrix.Rotation(angle,3,axis)
    world_matrix=posebones_CC['CC_Base_R_Hand'].matrix.to_3x3()
    rot_quaternion= (world_matrix.inverted()@rot_mat@world_matrix).to_quaternion()
    hand_right.rotation_quaternion=rot_quaternion
    scale = shogun_mid_vector.length/cc_mid_vector.length
    hand_right.scale=(scale,scale,scale)

    # left hand
    hand_left = posebones_CC['CC_Base_L_Hand']
    shogun_mid_vector =( posebones_shogun['LeftHand'].head - posebones_shogun['LeftHandMiddle3'].head)
    cc_mid_vector = (hand_left.head - posebones_CC['CC_Base_L_Mid3'].head)
    axis=cc_mid_vector.cross(shogun_mid_vector)
    angle=cc_mid_vector.angle(shogun_mid_vector)
    rot_mat=Matrix.Rotation(angle,3,axis)
    world_matrix=posebones_CC['CC_Base_L_Hand'].matrix.to_3x3()
    rot_quaternion= (world_matrix.inverted()@rot_mat@world_matrix).to_quaternion()
    hand_left.rotation_quaternion=rot_quaternion
    scale = shogun_mid_vector.length/cc_mid_vector.length
    hand_left.scale=(scale,scale,scale)
    # scale = shogun_mid_length/cc_mid_length
    # print(shogun_mid_length)
    # print(cc_mid_length)
    # # scale=3
    # hand_right.scale=(scale,scale,scale)
    # hand_left.scale=(scale,scale,scale)
    bpy.context.view_layer.update()
    # cc_sum=0.3833811973274893
    # shogun_sum=0.4090509388595722
    _apply_CC_rest_pose(armature_CC)
    # shogun_mid=0.10675037050373057
    # cc_mid=0.10043851767543875

    lefthand_bones=['CC_Base_L_Hand',
     'CC_Base_L_Pinky1', 'CC_Base_L_Pinky2', 'CC_Base_L_Pinky3', 'CC_Base_L_Ring1', 
    'CC_Base_L_Ring2', 'CC_Base_L_Ring3', 'CC_Base_L_Mid1', 'CC_Base_L_Mid2', 'CC_Base_L_Mid3', 'CC_Base_L_Index1', 
    'CC_Base_L_Index2', 'CC_Base_L_Index3', 'CC_Base_L_Thumb1', 'CC_Base_L_Thumb2', 'CC_Base_L_Thumb3',]
    quaternions_L=[[0.9979872703552246, -0.06327740848064423, 0.002733170287683606, 0.0030627641826868057],#[0.9504157900810242, -0.1316140592098236, 0.2603560984134674, -0.10771387815475464],
                [0.9966228604316711 ,-0.08127740770578384 ,2.907436282839626e-05, -0.011698123998939991],
                [1.0,0.0, 0.0,0.0],
                [1.0,0.0, 0.0,0.0],
                [0.9999842047691345, -0.005586417391896248, 1.0019186447607353e-05, -0.0008043819689191878],
                [1.0, 0.0 ,0.0 ,0.0],
                [1.0, 0.0 ,0.0 ,0.0],
                [1.0, 0.0 ,0.0 ,0.0],
                [1.0, 0.0 ,0.0 ,0.0],
                [1.0, 0.0 ,0.0 ,0.0],
                [0.9998961687088013 ,0.01428158674389124, 0.00014604476746171713, 0.0019383052131161094],
                [1.0, 0.0, 0.0 ,0.0],
                [1.0, 0.0, 0.0, 0.0],
                [0.9818609356880188, -0.1722450852394104, 0.07869839668273926, -0.009367064572870731],
                [0.9526671171188354 ,0.087397500872612, -0.2911374866962433, 0.005112813785672188],
                [1.0, 0.0, 0.0 ,0.0]]
    quaternions_R=[[0.9979326128959656, -0.06412996351718903, -0.0027720134239643812, -0.0031840382143855095],
                [0.9966222643852234,-0.08128594607114792,-3.29270405927673e-05,0.01169199962168932],
                [1.0,-8.772050932748243e-06,4.429530690686079e-06,6.876572297187522e-05],
                [1.0,2.9612354410346597e-05,-7.2686016210354865e-06,3.702857065945864e-05],
                [0.999984085559845,-0.005589426029473543,-1.6348651115549728e-05,0.000791875587310642],
                [1.0,1.662875547481235e-05,9.637609764467925e-06,-2.8446218493627384e-05],
                [1.0,-8.050079486565664e-06,-3.503992502373876e-06,0.00011613816604949534],
                [1.0,-3.969253725699673e-07,-5.410061021393631e-06,2.9979053579154424e-05],
                [1.0,1.2761422112816945e-05,3.871964054269483e-06,-4.6364621084649116e-05],
                [1.0,-5.254125426290557e-05,-3.6558510601025773e-06,0.0001460871717426926],
                [0.9998956918716431,0.014297597110271454,-0.00015313856420107186,-0.002046008361503482],
                [0.9999998807907104,-0.0003723816480487585,3.726368049683515e-06,-0.0003448901989031583],
                [0.9999996423721313,0.0005913600907661021,4.878196705249138e-05,0.0007511146832257509],
                [0.981866717338562,-0.17221233248710632,-0.07869464159011841,0.009375492110848427],
                [0.9526734948158264,0.08735395967960358,0.29112958908081055,-0.005108204670250416],
                [1.0,7.591024041175842e-05,-2.3515895009040833e-06,0.00020456688071135432]]
    for index,bone in enumerate(lefthand_bones):
        if index==0:
            continue
        posebones_CC[bone].rotation_mode='QUATERNION'
        posebones_CC[bone].rotation_quaternion = quaternions_L[index]
        bone_R=bone.replace('_L_','_R_')
        posebones_CC[bone_R].rotation_mode='QUATERNION'
        posebones_CC[bone_R].rotation_quaternion = quaternions_R[index]
        # bpy.context.view_layer.update()
    # print('new round')
    # for index,bone_L in enumerate(lefthand_bones):
    #     bone_R=bone_L.replace('_L_','_R_')
    #     m1=posebones_CC[bone_R].matrix.to_3x3()
    #     constraint = posebones_CC[bone_R].constraints.new('COPY_ROTATION')
    #     constraint.target = armature_CC
    #     constraint.subtarget = bone_L
    #     constraint.invert_y=True
    #     constraint.invert_z=True
    #     bpy.context.view_layer.update()
    #     m2=posebones_CC[bone_R].matrix.to_3x3()
    #     quat = (m1.inverted() @ m2).to_quaternion()
    #     print(f'[{quat[0]},{quat[1]},{quat[2]},{quat[3]}]')
    # print('new round..')
    # for index,bone_L in enumerate(lefthand_bones):
    #     print('\n',posebones_CC[bone_L].tail,'\n',posebones_CC[bone_L.replace('_L_','_R_')].tail)
    _apply_CC_rest_pose(armature_CC)


    bpy.context.view_layer.objects.active = armature_CC
    bpy.ops.object.mode_set(mode='EDIT')
    edit_bones_CC=armature_CC.data.edit_bones
    # add palm/metacarpal bones
    for side_shogun in ['Left','Right']:
        side_CC=side_shogun[0]
        for finger_CC in ['Index','Ring','Pinky']:
            name_CC=f'CC_Base_{side_CC}_{finger_CC}Root'
            name_shogun=f'{side_shogun}Hand{finger_CC}'
            bpy.ops.armature.bone_primitive_add(name=name_CC)
            # edit_bones_CC[name_CC].head = edit_bones_CC[f'CC_Base_{side_CC}_Hand'].head + posebones_shogun[name_shogun].head-posebones_shogun[f'{side_shogun}Hand'].head
            edit_bones_CC[name_CC].head =posebones_shogun[name_shogun].head
            edit_bones_CC[name_CC].tail = posebones_shogun[name_shogun+'1'].head
        
        edit_bones_CC[f'CC_Base_{side_CC}_Hand'].tail = edit_bones_CC[f'CC_Base_{side_CC}_Mid1'].head
        edit_bones_CC[f'CC_Base_{side_CC}_IndexRoot'].parent = edit_bones_CC[f'CC_Base_{side_CC}_Hand']
        edit_bones_CC[f'CC_Base_{side_CC}_Thumb1'].parent = edit_bones_CC[f'CC_Base_{side_CC}_IndexRoot']
        edit_bones_CC[f'CC_Base_{side_CC}_Index1'].parent=edit_bones_CC[f'CC_Base_{side_CC}_IndexRoot']
        edit_bones_CC[f'CC_Base_{side_CC}_RingRoot'].parent = edit_bones_CC[f'CC_Base_{side_CC}_Hand']
        edit_bones_CC[f'CC_Base_{side_CC}_Ring1'].parent = edit_bones_CC[f'CC_Base_{side_CC}_RingRoot']
        edit_bones_CC[f'CC_Base_{side_CC}_PinkyRoot'].parent = edit_bones_CC[f'CC_Base_{side_CC}_RingRoot']
        edit_bones_CC[f'CC_Base_{side_CC}_Pinky1'].parent = edit_bones_CC[f'CC_Base_{side_CC}_PinkyRoot']

        edit_bones_CC[f'CC_Base_{side_CC}_Thumb1'].head=posebones_shogun[f'{side_shogun}HandThumb1'].head
        # edit_bones_CC[f'CC_Base_{side_CC}_Thumb1'].tail=posebones_shogun[f'{side_shogun}HandThumb2'].head
        

        edit_bones_CC[f'CC_Base_{side_CC}_IndexRoot'].tail=posebones_shogun[f'{side_shogun}HandIndex1'].head
        edit_bones_CC[f'CC_Base_{side_CC}_Index1'].head=posebones_shogun[f'{side_shogun}HandIndex1'].head
        edit_bones_CC[f'CC_Base_{side_CC}_Index1'].tail=posebones_shogun[f'{side_shogun}HandIndex2'].head
        edit_bones_CC[f'CC_Base_{side_CC}_Index2'].head=posebones_shogun[f'{side_shogun}HandIndex2'].head
        edit_bones_CC[f'CC_Base_{side_CC}_Index2'].tail=posebones_shogun[f'{side_shogun}HandIndex3'].head

        edit_bones_CC[f'CC_Base_{side_CC}_Hand'].tail=posebones_shogun[f'{side_shogun}HandMiddle1'].head
        edit_bones_CC[f'CC_Base_{side_CC}_Mid1'].head=posebones_shogun[f'{side_shogun}HandMiddle1'].head
        edit_bones_CC[f'CC_Base_{side_CC}_Mid1'].tail=posebones_shogun[f'{side_shogun}HandMiddle2'].head
        edit_bones_CC[f'CC_Base_{side_CC}_Mid2'].head=posebones_shogun[f'{side_shogun}HandMiddle2'].head
        edit_bones_CC[f'CC_Base_{side_CC}_Mid2'].tail=posebones_shogun[f'{side_shogun}HandMiddle3'].head
        
        edit_bones_CC[f'CC_Base_{side_CC}_RingRoot'].tail=posebones_shogun[f'{side_shogun}HandRing1'].head
        edit_bones_CC[f'CC_Base_{side_CC}_Ring1'].head=posebones_shogun[f'{side_shogun}HandRing1'].head
        edit_bones_CC[f'CC_Base_{side_CC}_Ring1'].tail=posebones_shogun[f'{side_shogun}HandRing2'].head
        edit_bones_CC[f'CC_Base_{side_CC}_Ring2'].head=posebones_shogun[f'{side_shogun}HandRing2'].head
        edit_bones_CC[f'CC_Base_{side_CC}_Ring2'].tail=posebones_shogun[f'{side_shogun}HandRing3'].head

    bpy.ops.object.mode_set(mode='OBJECT')
    # bpy.ops.object.select_all(action='DESELECT')
    # for obj in armature_CC.children:
    #     obj.select_set(True)
    # armature_CC.select_set(True)
    # bpy.context.view_layer.objects.active=armature_CC
    # bpy.ops.object.parent_set(type='ARMATURE_AUTO')

    


    # bpy.context.view_layer.objects.active = armature_CC
    # bpy.ops.object.mode_set(mode='EDIT')
    # edit_bones_CC=armature_CC.data.edit_bones
    # # add palm/metacarpal bones
    # for side_shogun in ['Left','Right']:
    #     side_CC=side_shogun[0]
    #     for finger_CC in ['Index','Ring','Pinky']:
    #         name_CC=f'CC_Base_{side_CC}_{finger_CC}Root'
    #         name_shogun=f'{side_shogun}Hand{finger_CC}'
    #         bpy.ops.armature.bone_primitive_add(name=name_CC)
    #         edit_bones_CC[name_CC].head = edit_bones_CC[f'CC_Base_{side_CC}_Hand'].head + posebones_shogun[name_shogun].head-posebones_shogun[f'{side_shogun}Hand'].head
    #         edit_bones_CC[name_CC].tail = edit_bones_CC[name_CC.replace('Root','1')].head
    #     edit_bones_CC[f'CC_Base_{side_CC}_Hand'].tail = edit_bones_CC[f'CC_Base_{side_CC}_Mid1'].head
    #     edit_bones_CC[f'CC_Base_{side_CC}_IndexRoot'].parent = edit_bones_CC[f'CC_Base_{side_CC}_Hand']
    #     edit_bones_CC[f'CC_Base_{side_CC}_Thumb1'].parent = edit_bones_CC[f'CC_Base_{side_CC}_IndexRoot']
    #     edit_bones_CC[f'CC_Base_{side_CC}_Index1'].parent=edit_bones_CC[f'CC_Base_{side_CC}_IndexRoot']
    #     edit_bones_CC[f'CC_Base_{side_CC}_RingRoot'].parent = edit_bones_CC[f'CC_Base_{side_CC}_Hand']
    #     edit_bones_CC[f'CC_Base_{side_CC}_Ring1'].parent = edit_bones_CC[f'CC_Base_{side_CC}_RingRoot']
    #     edit_bones_CC[f'CC_Base_{side_CC}_PinkyRoot'].parent = edit_bones_CC[f'CC_Base_{side_CC}_RingRoot']
    #     edit_bones_CC[f'CC_Base_{side_CC}_Pinky1'].parent = edit_bones_CC[f'CC_Base_{side_CC}_PinkyRoot']

    # bpy.ops.object.mode_set(mode='OBJECT')
    # bpy.ops.object.select_all(action='DESELECT')
    # for obj in armature_CC.children:
    #     obj.select_set(True)
    # armature_CC.select_set(True)
    # bpy.context.view_layer.objects.active=armature_CC
    # bpy.ops.object.parent_set(type='ARMATURE_AUTO')
    return

def _adjust_CC_trunk(armature_CC,posebones_shogun):
    # posebones_CC=armature_CC.pose.bones
    # height=posebones_CC['CC_Base_L_Clavicle'].tail[2]-posebones_CC['CC_Base_Hip'].head[2]
    # target_height=posebones_shogun['LeftShoulder'].head[2]-posebones_shogun['Hips'].head[2]
    # # posebones_CC['CC_Base_R_Clavicle'].location[0] = target_height - height
    # # posebones_CC['CC_Base_L_Clavicle'].location[0] = -target_height + height
    # posebones_CC['CC_Base_Spine03'].location[1]= target_height - height
    # _apply_rest_pose(armature_CC)

    # bpy.context.view_layer.objects.active = armature_CC
    # bpy.ops.object.mode_set(mode='EDIT')
    # edit_bones_CC=armature_CC.data.edit_bones
    # edit_bones_CC['CC_Base_Spine03'].head[2] -= target_height - height
    # edit_bones_CC['CC_Base_Spine03'].tail[2] -= target_height - height
    # bpy.ops.object.mode_set(mode='OBJECT')

    posebones_CC=armature_CC.pose.bones
    height=posebones_CC['CC_Base_L_Clavicle'].tail[2]-posebones_CC['CC_Base_Hip'].head[2]
    target_height=posebones_shogun['LeftShoulder'].head[2]-posebones_shogun['Hips'].head[2]
    scale=target_height/height
    posebones_CC['CC_Base_Hip'].scale=(scale,scale,scale)

    # posebones_CC['CC_Base_R_Clavicle'].location[0] = target_height - height
    # posebones_CC['CC_Base_L_Clavicle'].location[0] = -target_height + height
    # posebones_CC['CC_Base_Spine03'].location[1]= target_height - height
    _apply_CC_rest_pose(armature_CC)


    # print(f'trunk height:{height},target height:{target_height}')
    # waist_height=posebones_CC['CC_Base_Waist'].tail[1] - posebones_CC['CC_Base_Waist'].head[1]
    # spine1_height=posebones_CC['CC_Base_Spine01'].tail[1] - posebones_CC['CC_Base_Spine01'].head[1]
    # spine2_height=posebones_CC['CC_Base_Spine02'].tail[1] - posebones_CC['CC_Base_Spine02'].head[1]
    # spine3_height=posebones_CC['CC_Base_Spine03'].tail[1] - posebones_CC['CC_Base_Spine03'].head[1]
    # total_height=waist_height+spine1_height+spine2_height+spine3_height

    # posebones_CC['CC_Base_Waist'].location[1] = (target_height - height )*(waist_height/total_height)
    # posebones_CC['CC_Base_Spine01'].location[1]= (target_height - height )*(spine1_height/total_height)
    # posebones_CC['CC_Base_Spine02'].location[1]= (target_height - height )*(spine2_height/total_height)
    # posebones_CC['CC_Base_Spine03'].location[1]=(target_height - height )*(spine3_height/total_height)
    
    # waist_height=posebones_CC['CC_Base_Waist'].head[1] - posebones_CC['CC_Base_Hip'].head[1]
    # spine1_height=posebones_CC['CC_Base_Spine01'].head[1] - posebones_CC['CC_Base_Waist'].head[1]
    # spine2_height=posebones_CC['CC_Base_Spine02'].head[1] - posebones_CC['CC_Base_Spine01'].head[1]
    # spine3_height=posebones_CC['CC_Base_Spine03'].head[1] - posebones_CC['CC_Base_Spine02'].head[1]
    
    # total_height = waist_height + spine1_height + spine2_height + spine3_height
    # posebones_CC['CC_Base_Waist'].location[1] = (target_height - height)*(waist_height/total_height)
    # posebones_CC['CC_Base_Spine01'].location[1]= (target_height -height )*(spine1_height/total_height)
    # posebones_CC['CC_Base_Spine02'].location[1]= (target_height -height )*(spine2_height/total_height)
    # posebones_CC['CC_Base_Spine03'].location[1]= (target_height -height )*(spine3_height/total_height)
    # spine3_height=posebones_CC['CC_Base_Spine03'].head[2] - posebones_CC['CC_Base_Spine03'].tail[2]
    # print(target_height,height)
    # spine3_height * (scale - 1) = 
    # scale= (target_height - height)/spine3_height + 1
    # print(f'scale::{scale}')
    # posebones_CC['CC_Base_Spine03'].scale = (1,scale,1)
    # bpy.context.view_layer.update()
    return

def _adjust_CC_legs(posebones_CC,posebones_shogun):
    # change the length of the upperleg
    length_upperleg = posebones_CC['CC_Base_L_Thigh'].head[2]-posebones_CC['CC_Base_L_Calf'].head[2]
    target_length_upperleg = posebones_shogun['LeftUpLeg'].head[2] - posebones_shogun['LeftLeg'].head[2]
    scale = target_length_upperleg / length_upperleg
    posebones_CC['CC_Base_L_Thigh'].scale = (scale,scale,scale)
    posebones_CC['CC_Base_R_Thigh'].scale = (scale,scale,scale)
    bpy.context.view_layer.update()

    # change the length of the lowerleg
    length_lowerleg = posebones_CC['CC_Base_L_Calf'].head[2]-posebones_CC['CC_Base_L_Foot'].head[2]
    target_length_lowerleg = posebones_shogun['LeftLeg'].head[2] - posebones_shogun['LeftFoot'].head[2]
    scale = target_length_lowerleg / length_lowerleg
    posebones_CC['CC_Base_L_Calf'].scale = (scale,scale,scale)
    posebones_CC['CC_Base_R_Calf'].scale = (scale,scale,scale)
    bpy.context.view_layer.update()

    # # change the size of the foot
    # scale = 1.534 * posebones_shogun['RightFoot'].length / posebones_CC['CC_Base_R_Foot'].length
    
    posebones_CC['CC_Base_L_Foot'].location = posebones_CC['CC_Base_L_Foot'].matrix.to_3x3().inverted() @ Vector((0,0,MESH_ANKLE_DELTA))
    posebones_CC['CC_Base_R_Foot'].location = posebones_CC['CC_Base_R_Foot'].matrix.to_3x3().inverted() @ Vector((0,0,MESH_ANKLE_DELTA))
    # posebones_CC['CC_Base_L_Foot'].scale = (1,scale,scale)
    # posebones_CC['CC_Base_R_Foot'].scale = (1,scale,scale)
    # bpy.context.view_layer.update()
    _apply_CC_rest_pose(armature_CC)
    return

def _edit_CC_armature(armature_CC,armature_shogun):
    bpy.context.view_layer.objects.active = armature_CC
    bpy.ops.object.mode_set(mode='EDIT')
    edit_bones_CC=armature_CC.data.edit_bones
    # # lower down the hip to the same height of the upperleg joint
    # bone_hip = edit_bones_CC['CC_Base_Hip']
    # bone_hip.head[2] = edit_bones_CC['CC_Base_L_Thigh'].head[2]
    # add a piece of spine bone and link
    edit_bones_CC['CC_Base_Spine02'].name='CC_Base_Spine03'
    bpy.ops.armature.bone_primitive_add(name='CC_Base_Spine02')
    bone_spine = edit_bones_CC['CC_Base_Spine02']
    bone_spine.parent = edit_bones_CC['CC_Base_Spine01']
    edit_bones_CC['CC_Base_Spine03'].parent = bone_spine

    posebones_shogun=armature_shogun.pose.bones
    bone_waist = edit_bones_CC['CC_Base_Waist']
    bone_hip = edit_bones_CC['CC_Base_Hip']
    bone_waist.head = bone_hip.head + (posebones_shogun['Spine'].head - posebones_shogun['Hips'].head)
    bone_waist.tail = bone_waist.head + (posebones_shogun['Spine1'].head - posebones_shogun['Spine'].head)

    bone_spine1 = edit_bones_CC['CC_Base_Spine01']
    bone_spine2 = edit_bones_CC['CC_Base_Spine02']
    bone_spine3 = edit_bones_CC['CC_Base_Spine03']
    bone_spine1.head = bone_waist.tail
    bone_spine1.tail = bone_spine1.head + (posebones_shogun['Spine2'].head - posebones_shogun['Spine1'].head)
    bone_spine2.head = bone_spine1.tail
    bone_spine2.tail = bone_spine2.head + (posebones_shogun['Spine3'].head - posebones_shogun['Spine2'].head)
    bone_spine3.head = bone_spine2.tail
    bone_spine3.tail = bone_spine3.head + (posebones_shogun['LeftShoulder'].head - posebones_shogun['Spine3'].head)

    # edit_bones_CC['CC_Base_L_Breast'].parent
    # edit_bones_CC['CC_Base_R_Breast']
    edit_bones_CC['CC_Base_L_RibsTwist'].parent=bone_spine2
    edit_bones_CC['CC_Base_R_RibsTwist'].parent=bone_spine2

    # adjust locations of neck and head bones
    bone_neck1=edit_bones_CC['CC_Base_NeckTwist01']
    bone_neck2=edit_bones_CC['CC_Base_NeckTwist02']
    bone_head = edit_bones_CC['CC_Base_Head']
    bone_neck1.head = bone_spine3.tail + (posebones_shogun['Neck'].head-posebones_shogun['LeftShoulder'].head)
    bone_neck1.tail = bone_neck1.head + (posebones_shogun['Neck1'].head-posebones_shogun['Neck'].head)
    bone_neck2.head = bone_neck1.tail 
    bone_neck2.tail = bone_neck2.head + (posebones_shogun['Head'].head-posebones_shogun['Neck1'].head)
    bone_head.head = bone_neck2.tail

    # make the head of the shoulder bones to the middle
    edit_bones_CC['CC_Base_R_Clavicle'].head[0]=0
    edit_bones_CC['CC_Base_L_Clavicle'].head[0]=0

    # adjust the foot bones
    # edit_bones_CC['CC_Base_L_Foot'].head = edit_bones_CC['CC_Base_L_Calf'].head + posebones_shogun['LeftFoot'].head - posebones_shogun['LeftLeg'].head 
    # edit_bones_CC['CC_Base_R_Foot'].head = edit_bones_CC['CC_Base_R_Calf'].head + posebones_shogun['RightFoot'].head - posebones_shogun['RightLeg'].head 
    # edit_bones_CC['CC_Base_L_Foot'].head[2] +=0.01
    # edit_bones_CC['CC_Base_R_Foot'].head[2] +=0.01
    edit_bones_CC['CC_Base_L_Foot'].tail = edit_bones_CC['CC_Base_L_Foot'].head + posebones_shogun['LeftFoot'].tail - posebones_shogun['LeftFoot'].head
    edit_bones_CC['CC_Base_R_Foot'].tail = edit_bones_CC['CC_Base_R_Foot'].head + posebones_shogun['RightFoot'].tail - posebones_shogun['RightFoot'].head
    edit_bones_CC['CC_Base_L_ToeBase'].head = edit_bones_CC['CC_Base_L_Foot'].tail
    edit_bones_CC['CC_Base_R_ToeBase'].head = edit_bones_CC['CC_Base_R_Foot'].tail
    edit_bones_CC['CC_Base_L_ToeBase'].tail = edit_bones_CC['CC_Base_L_ToeBase'].head + posebones_shogun['LeftToeBase'].tail - posebones_shogun['LeftToeBase'].head
    edit_bones_CC['CC_Base_R_ToeBase'].tail = edit_bones_CC['CC_Base_R_ToeBase'].head + posebones_shogun['RightToeBase'].tail - posebones_shogun['RightToeBase'].head
        
    bpy.ops.object.mode_set(mode='OBJECT')
    # bpy.ops.object.select_all(action='DESELECT')
    # for obj in armature_CC.children:
    #     obj.select_set(True)
    # armature_CC.select_set(True)
    # bpy.context.view_layer.objects.active=armature_CC
    # bpy.ops.object.parent_set(type='ARMATURE_AUTO')
    return

def _change_shogun_bone_names(armature_shogun):
    """e.g. Shogun armature name:Take002, hip bone name: \'zzy:Hips\' --> 'Hips' """
    posebones_shogun = armature_shogun.pose.bones
    try:
        print('Changing shogun armature bone names...')
        for bone in posebones_shogun:
            bone.name = bone.name[bone.name.index(':')+1 : ]
    except:
        print('Failed. Probably already changed last run.')
    else:
        print('Success.')

def _initialize_armatures(armature_CC,armature_shogun):
    armature_CC.rotation_euler= Euler((0,0,3.1415926536),'XYZ')
    armature_CC.select_set(True)
    bpy.ops.object.select_all(action='DESELECT')
    armature_CC.select_set(True)
    bpy.context.view_layer.objects.active = armature_CC
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    armature_shogun.select_set(True)
    bpy.ops.object.select_all(action='DESELECT')
    armature_shogun.select_set(True)
    bpy.ops.object.mode_set(mode='POSE')
    bpy.ops.pose.loc_clear()
    bpy.ops.pose.rot_clear()
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.view_layer.objects.active = armature_shogun
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    # lower down the hip to the same height of the upperleg joint
    bpy.context.view_layer.objects.active = armature_CC
    bpy.ops.object.mode_set(mode='EDIT')
    edit_bones_CC=armature_CC.data.edit_bones
    bone_hip = edit_bones_CC['CC_Base_Hip']
    bone_hip.head[2] = edit_bones_CC['CC_Base_L_Thigh'].head[2]

    edit_bones_CC.remove(edit_bones_CC['CC_Base_BoneRoot'])


    bpy.ops.object.mode_set(mode='OBJECT')
    posebones_CC=armature_CC.pose.bones
    armature_CC.location = - posebones_CC['CC_Base_Hip'].head
    bpy.ops.object.select_all(action='DESELECT')
    armature_CC.select_set(True)
    bpy.context.view_layer.objects.active = armature_CC
    bpy.ops.object.transform_apply(location=True, rotation=False, scale=False)
    bpy.context.view_layer.update()

def _rebind(armature_CC):
    bpy.context.view_layer.update()
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active=armature_CC
    added_bones = ['CC_Base_Spine03', 'CC_Base_L_Hand','CC_Base_R_Hand']
    for obj in armature_CC.children:
        # print(obj.name)
        # print(obj.vertex_groups.keys())
        for bone in added_bones:
            if bone in obj.vertex_groups.keys():
                # print(obj.name)
                obj.select_set(True)
                break
    armature_CC.select_set(True)
    bpy.ops.object.parent_set(type='ARMATURE_AUTO')


def _attach_cubes(name_CC_armature):
    armature_CC = bpy.data.objects[name_CC_armature]
    # translation = armature_CC.location
    for posebone in armature_CC.pose.bones:
        if posebone.name in ['CC_Base_L_ToeBaseShareBone','CC_Base_R_ToeBaseShareBone']:
            continue
        name_cube = f'{name_CC_armature}_{posebone.name}_Cube'
        bpy.ops.mesh.primitive_cube_add(size=0.01,location=posebone.tail)
        bpy.context.object.name = name_cube
    armature_CC.select_set(True)
    bpy.ops.object.select_all(action='DESELECT')
    for posebone in armature_CC.pose.bones:
        if posebone.name in ['CC_Base_L_ToeBaseShareBone','CC_Base_R_ToeBaseShareBone']:
            continue
        name_cube = f'{name_CC_armature}_{posebone.name}_Cube'
        bpy.data.objects[name_cube].select_set(True)
    armature_CC.select_set(True)
    bpy.context.view_layer.objects.active=armature_CC
    bpy.ops.object.parent_set(type='ARMATURE_AUTO')

def calibrate(armature_CC,armature_shogun):
    print('changing CC armature to fit shogun armature...')
    posebones_CC=armature_CC.pose.bones
    posebones_shogun=armature_shogun.pose.bones
    
    _change_shogun_bone_names(armature_shogun)
    _initialize_armatures(armature_CC,armature_shogun)
    
    _adjust_CC_arm_rotations(armature_CC)
    _adjust_CC_trunk(armature_CC,posebones_shogun)
    _edit_CC_armature(armature_CC,armature_shogun)
    _adjust_CC_arm_lengths(posebones_CC,posebones_shogun)
    _adjust_CC_legs(posebones_CC,posebones_shogun)
    _adjust_CC_hands(posebones_CC,posebones_shogun,armature_CC)
    _rebind(armature_CC)
    # _apply_rest_pose(armature_CC)

    # armature_CC.location = - posebones_CC['CC_Base_Hip'].head
    # # armature_CC.select_set(True)
    # bpy.ops.object.select_all(action='DESELECT')
    # armature_CC.select_set(True)
    # bpy.context.view_layer.objects.active = armature_CC
    # bpy.ops.object.transform_apply(location=True, rotation=False, scale=False)


    print('CC armature fitted...')

armature_CC = bpy.data.objects['camila_transfer.003']
calibrate(armature_CC,bpy.data.objects['Armature'])
# calibrate(armature_CC,bpy.data.objects['Armature'])
# import_shogun_fbx(r'C:\Users\18715\Documents\ShogunTake\Take007.fbx')
# _apply_rest_pose(bpy.context.)

# test

# posebones_CC=armature_CC.pose.bones
# lefthand_bones=['CC_Base_L_Hand', 'CC_Base_L_Pinky1', 'CC_Base_L_Pinky2', 'CC_Base_L_Pinky3', 'CC_Base_L_Ring1', 
#     'CC_Base_L_Ring2', 'CC_Base_L_Ring3', 'CC_Base_L_Mid1', 'CC_Base_L_Mid2', 'CC_Base_L_Mid3', 'CC_Base_L_Index1', 
#     'CC_Base_L_Index2', 'CC_Base_L_Index3', 'CC_Base_L_Thumb1', 'CC_Base_L_Thumb2', 'CC_Base_L_Thumb3',]

# for index,bone_L in enumerate(lefthand_bones):
#     bone_R=bone_L.replace('_L_','_R_')
#     m1=posebones_CC[bone_R].matrix.to_3x3()
#     constraint = posebones_CC[bone_R].constraints.new('COPY_ROTATION')
#     constraint.target = armature_CC
#     constraint.subtarget = bone_L
#     constraint.invert_y=True
#     constraint.invert_z=True
#     bpy.context.view_layer.update()
#     m2=posebones_CC[bone_R].matrix.to_3x3()
#     quat = (m1.inverted() @ m2).to_quaternion()
#     print(f'[{quat[0]},{quat[1]},{quat[2]},{quat[3]}]')
# print('new round..')


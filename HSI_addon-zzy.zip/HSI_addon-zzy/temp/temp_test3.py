import bpy




def import_character():
    filepath=r"D:\HSI\CC4Characters\camila_walk\camila_walk.Fbx"
    filepath=r"D:\HSI\CC4Characters\kevin\kevin.Fbx"
    bpy.ops.cc3.importer(filepath=filepath,param='IMPORT',use_anim=False)
    for obj in bpy.context.selected_objects:
        if obj.type=='ARMATURE':
            armature_CC = obj
        if 'CC_Base_Body' in obj.name:
            obj.hide_set(True)

    filepath=r"D:\HSI\CC4Characters\camila_walk\camila_walk_del.Fbx"
    filepath=r"D:\HSI\CC4Characters\kevin\kevin_del.Fbx"
    bpy.ops.cc3.importer(filepath=filepath,param='IMPORT',use_anim=False)
    armature_CC_del=bpy.context.object
    for obj in bpy.context.selected_objects:
        if 'CC_Base_Body' in obj.name:
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            bpy.context.view_layer.objects.active=obj
            bpy.ops.object.duplicate()
            mesh_del = bpy.context.object

    mesh_del.name = 'CC_Base_Body_HiddenFaceDeleted'
    mesh_del.modifiers['Armature'].object = armature_CC
    mesh_del.parent=armature_CC


    bpy.ops.object.select_all(action='DESELECT')
    armature_CC_del.select_set(True)
    bpy.context.view_layer.objects.active=armature_CC_del

    bpy.ops.cc3.importer(param='DELETE_CHARACTER')

    return armature_CC

def apply_physics(armature_CC):
    bpy.context.view_layer.objects.active=armature_CC
    for obj in armature_CC.children:
        if  'CC_Base_Body' in obj.name and 'HiddenFaceDeleted' not in obj.name:
            body_mesh_full=obj
            print('chosen!')
    body_mesh_full.hide_set(False)
    bpy.context.view_layer.update()
    bpy.ops.cc3.setphysics(param='APPLY_PHYSICS')
    body_mesh_full.hide_set(True)

# armature_CC = import_character()

armature_CC = bpy.data.objects['camila_walk']
armature_CC = bpy.data.objects['kevin']
apply_physics(armature_CC)

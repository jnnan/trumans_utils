import bpy


def notusingthis():
    obj_source = bpy.data.objects['Basic_T_shirts.001']

    not_to_touch = ['CC_Base_Spine01', 'CC_Base_Spine03']
    to_touch = {}
    obj_dest = bpy.data.objects['Basic_T_shirts']

    for vertex_group in obj_dest.vertex_groups:
        if vertex_group.name in not_to_touch:
            continue
        else:
            obj_dest.vertex_groups.remove(vertex_group)
            # obj_dest.vertex_groups.new(name=name)

    for vertex_group in obj_source.vertex_groups:
        if vertex_group.name in not_to_touch:
            continue
        else:
            to_touch[vertex_group.index] = vertex_group.name

    for name in to_touch.values():
        obj_dest.vertex_groups.new(name=name)

    v_index_g_indices_list = [
        [v.index, [g.group for g in v.groups]] for v in obj_source.data.vertices]

    for v_index_g_indices in v_index_g_indices_list:
        v_index = v_index_g_indices[0]
        for g in v_index_g_indices[1]:
            try:
                group_name = to_touch[g]
            except:
                continue
            obj_dest.vertex_groups[group_name].add(
                [v_index], obj_source.vertex_groups[group_name].weight(v_index), 'REPLACE')


def _get_vertex_weights(obj):
    res = {}

    for vertex_group in obj.vertex_groups:
        res[vertex_group.name] = []

    for vertex in obj.data.vertices:
        for group_data in vertex.groups:
            res[obj.vertex_groups[group_data.group].name].append(
                (vertex.index, group_data.weight))
    
    return res


def _rebind(armature_CC):
    bpy.context.view_layer.update()
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = armature_CC
    affected_bones = ['CC_Base_Spine03', 'CC_Base_L_Hand', 'CC_Base_R_Hand']
    not_to_touch = ['CC_Base_Spine01', 'CC_Base_Spine02', 'CC_Base_Spine03',
                    'CC_Base_R_Hand',
                    'CC_Base_R_Mid1',
                    'CC_Base_R_Mid2',
                    'CC_Base_R_Mid3',
                    'CC_Base_R_IndexRoot',
                    'CC_Base_R_Thumb1',
                    'CC_Base_R_Thumb2',
                    'CC_Base_R_Thumb3',
                    'CC_Base_R_Index1',
                    'CC_Base_R_Index2',
                    'CC_Base_R_Index3',
                    'CC_Base_R_RingRoot',
                    'CC_Base_R_Ring1',
                    'CC_Base_R_Ring2',
                    'CC_Base_R_Ring3',
                    'CC_Base_R_PinkyRoot',
                    'CC_Base_R_Pinky1',
                    'CC_Base_R_Pinky2',
                    'CC_Base_R_Pinky3',

                    'CC_Base_L_Hand',
                    'CC_Base_L_Mid1',
                    'CC_Base_L_Mid2',
                    'CC_Base_L_Mid3',
                    'CC_Base_L_IndexRoot',
                    'CC_Base_L_Thumb1',
                    'CC_Base_L_Thumb2',
                    'CC_Base_L_Thumb3',
                    'CC_Base_L_Index1',
                    'CC_Base_L_Index2',
                    'CC_Base_L_Index3',
                    'CC_Base_L_RingRoot',
                    'CC_Base_L_Ring1',
                    'CC_Base_L_Ring2',
                    'CC_Base_L_Ring3',
                    'CC_Base_L_PinkyRoot',
                    'CC_Base_L_Pinky1',
                    'CC_Base_L_Pinky2',
                    'CC_Base_L_Pinky3', ]

    for obj in armature_CC.children:
        if obj.name == 'Rolled_sleeves_shirt.002':
            for bone in affected_bones:
                if bone in obj.vertex_groups.keys():
                    obj.select_set(True)
                    print('selected')
                    break
            if obj.select_get():
                weights = _get_vertex_weights(obj)
                print('weights got')
                bpy.ops.object.parent_set(type='ARMATURE_AUTO')
                print('automatic weights applied')
                _override_weights(obj, weights, not_to_touch)
                print('overridden')
                obj.select_set(False)


def _override_weights(obj, weights_data, not_to_touch):
    for vertex_group in obj.vertex_groups:
        if vertex_group.name not in not_to_touch:
            print(vertex_group.name)
            obj.vertex_groups.remove(vertex_group)
    for group_name, vw_data in weights_data.items():
        if group_name not in not_to_touch:
            obj.vertex_groups.new(name=group_name)
            for (v_index, weight) in vw_data:
                obj.vertex_groups[group_name].add([v_index], weight, 'REPLACE')


_rebind(bpy.data.objects['camila_transfer.002'])

print('rebounded!')

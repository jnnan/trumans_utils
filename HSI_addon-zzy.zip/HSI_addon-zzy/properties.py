# coding=UTF-8
# dont direct regist example class.

import bpy
from bpy.props import StringProperty, BoolProperty, EnumProperty, FloatProperty, IntProperty, CollectionProperty


class HSIProperties(bpy.types.PropertyGroup):

    cc4_fbx_path: StringProperty(
        default=r"D:\HSI\CC4Characters\zzy\zzy_clothes_latest2.Fbx",
        subtype="FILE_PATH",
        name="CC4 fbx path",
    )
    
    shogun_fbx_path: StringProperty(
        default=r"D:\FbxFromShogunPost\zzy_latest.fbx",
        subtype="FILE_PATH",
        name="Shogun fbx path"
    )
    
    name_armature_CC: StringProperty(
        default='',
        name="current CC armature"
    )
    
    name_VR_camera: StringProperty(
        default='Camera',
        name="Camera for VR helmet"
    )

    shogun_subject_name: StringProperty(
        name='Shogun subject name', description='Name of human subject in the Shogun Live software', default='zzy')
    
    recordings_path:StringProperty(
        default='D:\\HSI\\RecordingStorage\\',
        subtype='DIR_PATH',
        name='Recording storage path'
    )

    recording_fps:FloatProperty(
        default=30.0,
        name='Recording fps'
    )

    current_instruction_index:IntProperty(
        name='Current instruction index',
        default=0,
    )

    is_marker_debugging_now:BoolProperty(
        default=False,
        name='Marker debugging now'
    )

    streaming_state: EnumProperty(
        items=[('IDLING', '', ''), ('RECORDING', '', ''), ('LIVE', '', '')],
        name='Streaming state',
        description='Streaming state, idling means not using data from Vicon, recording means collecting data and ready to save, live means livestreaming',
        default='IDLING'
    )


    language_instructions:StringProperty(
        default="no instruction",
        name='Language instructions'
    )

    scene_objects:StringProperty(
        default="",
        name='Scene objects'
    )

    instruction_timepoints:StringProperty(
        default="",
        name='Instruction timepoints'
    )

    maximum_framenum:IntProperty(
        name='Maximum frame number',
        description='Maximum frame number of a recording',
        default=20000,
        min=1
    )

    restore_file_path:StringProperty(
        default=r"D:\HSI\RecordingStorage\extreme_pose.pkl",
        subtype='FILE_PATH',
        name='Restore path'
    )

    is_physics_enabled:BoolProperty(
        default=False,
        name='Physics On'
    )

    current_animation_index_display:IntProperty(
        name='Animation set',
        default=0,
        min=0,
        max=20
    )

    current_animation_index:IntProperty(
        name='Current',
        default=0,
        min=0,
        max=20
    )

    animation_sets:StringProperty(
        name='Animation sets',
        default='{}'
    )

classes = (
    HSIProperties,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.hsi_properties = bpy.props.PointerProperty(
        type=HSIProperties)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.hsi_properties


if __name__ == '__main__':
    register()

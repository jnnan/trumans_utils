
from bpy.props import StringProperty, BoolProperty
import bpy
import os
import importlib
import time
import datetime
import pickle as pkl
import numpy as np
import argparse
import traceback
import json
from bpy_extras.io_utils import ImportHelper
try:
    from vicon_dssdk import ViconDataStream
except:
    print(traceback.format_exc())
    # print(f'vicon import failed!')

from mathutils import Vector, Matrix, Quaternion
try:
    from . import hsi_script
    from .hsi_script.record import CC_BONE_NAMES
except:
    import hsi_script
    from hsi_script.record import CC_BONE_NAMES
    importlib.reload(hsi_script)


class HSI_OT_import_character(bpy.types.Operator):
    bl_idname = "hsi.import_cc4_fbx"
    bl_label = "Import CC4 FBX"
    bl_description = "Import CC4 character"

    filepath = bpy.props.StringProperty(
        default="",
    )

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.streaming_state == 'IDLING'

    def execute(self, context):
        cc4_path = context.scene.hsi_properties.cc4_fbx_path
        hsi_script.import_CC4_fbx(cc4_path)
        context.scene.hsi_properties.name_armature_CC = context.object.name
        return {'FINISHED'}


class HSI_OT_calibrate_CC_Shogun_armatures(bpy.types.Operator):
    bl_idname = "hsi.calibrate_cc_shogun_armatures"
    bl_label = "Calibrate CC/Shogun"
    bl_description = "Chagne the CC arm and hand rotations"

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.streaming_state == 'IDLING'

    def execute(self, context):
        shogun_path = context.scene.hsi_properties.shogun_fbx_path

        armature_shogun = hsi_script.import_shogun_fbx_post(
            filepath=shogun_path)
        armature_CC = bpy.data.objects[context.scene.hsi_properties.name_armature_CC]

        hsi_script.calibrate(armature_CC, armature_shogun)
        bpy.ops.object.select_all(action='DESELECT')
        armature_shogun.select_set(True)
        bpy.ops.object.delete()

        return {'FINISHED'}


class HSI_OT_calculate_CC_slider_values(bpy.types.Operator):
    bl_idname = "hsi.calculate_cc_slider_values"
    bl_label = "Calculate Slider"
    bl_description = "Calculate the CC slider values and print them"

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.streaming_state == 'IDLING'

    def execute(self, context):
        shogun_path = context.scene.hsi_properties.shogun_fbx_path
        armature_shogun = hsi_script.import_shogun_fbx_post(
            filepath=shogun_path)
        hsi_script.calculate_and_print_slider_values(armature_shogun)
        bpy.ops.object.select_all(action='DESELECT')
        armature_shogun.select_set(True)
        bpy.ops.object.delete()

        return {'FINISHED'}


class HSI_OT_pick_CC_armature(bpy.types.Operator):
    bl_idname = "hsi.pick_cc_armature"
    bl_label = "pick_CC_armature"
    bl_description = "Pick the CC armature to manipulate"

    filepath = bpy.props.StringProperty(
        default="",
    )

    @classmethod
    def poll(cls, context):
        return (context.object != None) and context.scene.hsi_properties.streaming_state == 'IDLING'

    def execute(self, context):
        bpy.context.scene.hsi_properties.name_armature_CC = bpy.context.active_object.name
        return {'FINISHED'}


class HSI_OT_remove_character(bpy.types.Operator):
    bl_idname = "hsi.remove_character"
    bl_label = "Remove CC character"
    bl_description = "Remove the current CC character"

    filepath = bpy.props.StringProperty(
        default="",
    )

    @classmethod
    def poll(cls, context):
        return bool(bpy.context.view_layer.objects.active) and context.scene.hsi_properties.streaming_state == 'IDLING'

    def execute(self, context):
        hsi_script.remove_CC4_character()
        return {'FINISHED'}


class HSI_OT_pick_VR_camera(bpy.types.Operator):
    bl_idname = "hsi.pick_vr_camera"
    bl_label = "pick_VR_camera"
    bl_description = "Pick a camera for VR"

    filepath = bpy.props.StringProperty(
        default="",
    )

    @classmethod
    def poll(cls, context):
        return (context.object != None) and context.scene.hsi_properties.streaming_state == 'IDLING'

    def execute(self, context):
        bpy.context.scene.hsi_properties.name_VR_camera = bpy.context.active_object.name
        return {'FINISHED'}


class CalibrateVRModalTimerOperator(bpy.types.Operator):
    """Operator to calibrate VR and Vicon systems"""
    bl_idname = "wm.calibrate_vr_modal_timer_operator"
    bl_label = "Calibrate VR"

    _timer = None

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.streaming_state == 'IDLING'

    def modal(self, context, event):
        if event.type in {'ESC'}:
            self.cancel(context)
            return {'CANCELLED'}

        if event.type == 'TIMER':
            print('TIMER')
            # Get VR Location
            wm = context.window_manager
            ctrl_loc_1 = wm.xr_session_state.controller_aim_location_get(
                context, 1)
            print('VR Location: ', ctrl_loc_1)

            if abs(ctrl_loc_1[0]) < 0.01 and abs(ctrl_loc_1[1]) < 0.01 and abs(ctrl_loc_1[2]) < 0.01:
                return {'PASS_THROUGH'}

            client = self.client
            client.GetFrame()

            transl = None
            subjectNames = client.GetSubjectNames()
            for subjectName in subjectNames:
                print(subjectName)
                if subjectName != 'Controller':
                    continue
                segmentNames = client.GetSegmentNames(subjectName)
                for segmentName in segmentNames:
                    print(segmentName)
                    transl, _ = client.GetSegmentGlobalTranslation(
                        subjectName, segmentName)
                    print("VICON Location: ", transl)
                    if abs(transl[0]) < 0.01 and abs(transl[1]) < 0.01 and abs(transl[2]) < 0.01:
                        return {'PASS_THROUGH'}

            if transl is None or ctrl_loc_1 is None:
                return {'PASS_THROUGH'}
            self.Vicon_locations.append(
                [transl[0] / 1000., transl[1] / 1000., transl[2] / 1000.])
            self.VR_locations.append(list(ctrl_loc_1))

            if len(self.Vicon_locations) > 10:
                self.cancel(context)
                return{'CANCELLED'}

        return {'PASS_THROUGH'}

    def execute(self, context):
        try:
            wm = context.window_manager
            self._timer = wm.event_timer_add(1.0, window=context.window)
            wm.modal_handler_add(self)

            cam = bpy.data.objects['Camera']
            bpy.context.view_layer.update()
            cam.matrix_world = Matrix()
            bpy.context.view_layer.update()

            self.VR_locations = []
            self.Vicon_locations = []

            parser = argparse.ArgumentParser(description=__doc__)
            parser.add_argument(
                'host', nargs='?', help="Host name, in the format of server:port", default="localhost:801")
            args = parser.parse_args()
        except Exception as e:
            print(e)

        return {'RUNNING_MODAL'}

    def cancel(self, context):
        wm = context.window_manager
        wm.event_timer_remove(self._timer)

        print(self.Vicon_locations)
        print('\n\n\n')
        print(self.VR_locations)

        try:
            _, M = hsi_script.rigid_transform_3D(
                np.matrix(self.Vicon_locations), np.matrix(self.VR_locations), False)
            cam = bpy.data.objects['Camera']
            bpy.context.view_layer.update()
            print('SETTING CAMERA: ', M)
            print('Location Before Setting', cam.location)
            cam.matrix_world = Matrix(np.array(M))
            bpy.context.view_layer.update()
            print('Location After Setting', cam.location)

        except Exception as e:
            print(traceback.format_exc())


class RecordModalTimerOperator(bpy.types.Operator):
    """Operator which runs itself from a timer"""
    bl_idname = "wm.record_modal_timer_operator"
    bl_label = "Start Recording"

    _timer = None

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.streaming_state == 'IDLING'

    def modal(self, context, event):
        if context.scene.hsi_properties.streaming_state != 'RECORDING':
            self.cancel(context)
            return {'CANCELLED'}

        if event.type == 'LEFT_CTRL':
            point = self.frame_num
            self.data_storage['Language']['timepoints'].append(point)
            cur_time = time.time()
            if cur_time - self.last_instruction_time >= 1.:
                context.scene.hsi_properties.current_instruction_index += 1
                self.last_instruction_time = cur_time

        if event.type == 'TIMER':

            if self.frame_num == 0:
                self.timestamp = time.time()
            elif self.frame_num == int(self.fps):
                delta_time = time.time() - self.timestamp
                real_fps = self.fps/delta_time
                self.fps_running_mean = real_fps
                print(
                    f'frame:{int(self.frame_num)}, real fps:{real_fps:.2f}, running mean:{self.fps_running_mean:.2f} expected fps:{self.fps}')
                self.timestamp = time.time()
                if real_fps < 0.95*self.fps:
                    self.report(
                        {'WARNING'}, f'Low fps! Real:{real_fps:.2f} Runnning mean:{self.fps_running_mean:.2f} Expected:{self.fps} ')
            elif self.frame_num % int(self.fps) == 0:
                delta_time = time.time() - self.timestamp
                real_fps = self.fps/delta_time
                self.fps_running_mean = real_fps * 0.25 + self.fps_running_mean * 0.75
                print(
                    f'frame:{int(self.frame_num)}, real fps:{real_fps:.2f}, running mean:{self.fps_running_mean:.2f} expected fps:{self.fps}')
                self.timestamp = time.time()
                if real_fps < 0.95*self.fps:
                    self.report(
                        {'WARNING'}, f'Low fps! Real:{real_fps:.2f} Runnning mean:{self.fps_running_mean:.2f} Expected:{self.fps} ')
            try:
                if self.frame_num >= self.max_frame_num:
                    print(
                        f'Cutting off recording at maximum frame number {self.max_frame_num}')
                    self.cancel(context)
                    return {'CANCELLED'}

                client = self.client

                client.GetFrame()
            except Exception as e:
                print(e)
                self.cancel(context)
                return {'CANCELLED'}

            try:
                armature_CC = bpy.data.objects[self.cc_name]
            except Exception as e:
                print(f'CC character named {self.cc_name} not found!')
                self.cancel(context)
                return {'CANCELLED'}

            try:
                subjectNames = client.GetSubjectNames()

                for subjectName in subjectNames:
                    if subjectName == self.shogun_name:
                        continue
                    segmentNames = client.GetSegmentNames(subjectName)
                    assert len(segmentNames) == 1
                    segmentName = segmentNames[0]
                    transl, _ = client.GetSegmentGlobalTranslation(
                        subjectName, segmentName)
                    rot, _ = client.GetSegmentGlobalRotationMatrix(
                        subjectName, segmentName)

                    if subjectName in self.subject_name_to_root_name.keys():
                        obj = bpy.data.objects[self.subject_name_to_root_name[subjectName]]
                        obj.location = Vector(transl) / 1000.
                        obj.rotation_quaternion = Matrix(rot).to_quaternion()
                        self.data_storage['Objects'][obj.name][self.frame_num][0:3] = np.array(
                            (obj.location[0], obj.location[1], obj.location[2]))
                        self.data_storage['Objects'][obj.name][self.frame_num][3:7] = np.array(
                            list(obj.rotation_quaternion))
                    else:
                        if self.frame_num % int(self.fps) == 0:
                            print(
                                f'warning: shogun subject \'{subjectName}\' not matching any object in blender.')

                ### marker debug start ###
                if context.scene.hsi_properties.is_marker_debugging_now:
                    for subjectName in subjectNames:
                        markerNames = client.GetMarkerNames(subjectName)
                        # print(subjectName,markerNames)
                        for mname_tuple in markerNames:
                            mname = mname_tuple[0]
                            name = f'marker_{mname}_{subjectName}'
                            # print(name)
                            if name not in bpy.data.objects:
                                bpy.ops.mesh.primitive_uv_sphere_add(
                                    enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(0.007, 0.007, 0.007))
                                bpy.context.view_layer.objects.active.name = name
                                bpy.data.objects[name].show_in_front = True
                            obj = bpy.data.objects[name]
                            markerPos, _ = client.GetMarkerGlobalTranslation(
                                subjectName, mname)
                            obj.location = Vector(markerPos)/1000
                ### marker debug end ###

                for subjectName in subjectNames:
                    if subjectName != self.shogun_name:
                        continue

                    for index, segmentName in enumerate(CC_BONE_NAMES):
                        bone = armature_CC.pose.bones[segmentName]
                        if segmentName == 'CC_Base_Hip':
                            transl, _ = client.GetSegmentGlobalTranslation(
                                subjectName, segmentName)
                            loc = Vector(transl)/1000
                            bone.location = (loc[0], loc[2], -loc[1])
                            self.data_storage['Human']['Hip translation'][self.frame_num] = np.array(
                                (bone.location[0], bone.location[1], bone.location[2]))
                        rot_mat_static = client.GetSegmentStaticRotationMatrix(
                            subjectName, segmentName)
                        rot_mat_local, _ = client.GetSegmentLocalRotationMatrix(
                            subjectName, segmentName)

                        trans_mat = self.trans_mats[segmentName]
                        bone.rotation_quaternion = (
                            trans_mat @ Matrix(rot_mat_static).inverted() @ Matrix(rot_mat_local)).to_quaternion()
                        self.data_storage['Human']['rotations'][self.frame_num][4 *
                                                                                index:4*index+4] = np.array(list(bone.rotation_quaternion))
                self.frame_num += 1

            except Exception as e:
                print(e)
                self.cancel(context)
                return {'CANCELLED'}

        return {'PASS_THROUGH'}

    def execute(self, context):
        context.scene.hsi_properties.streaming_state = 'RECORDING'
        wm = context.window_manager
        self.fps = context.scene.hsi_properties.recording_fps
        self._timer = wm.event_timer_add(1.0/self.fps, window=context.window)
        wm.modal_handler_add(self)

        self.shogun_name = bpy.context.scene.hsi_properties.shogun_subject_name
        self.cc_name = bpy.context.scene.hsi_properties.name_armature_CC
        self.trans_mats = {}
        self.subject_name_to_root_name = {}
        self.frame_num = 0
        self.max_frame_num = context.scene.hsi_properties.maximum_framenum

        self.data_storage = {}
        self.data_storage['Metadata'] = {}
        self.data_storage['Metadata']['performer'] = self.shogun_name + \
            '@' + bpy.context.scene.hsi_properties.shogun_fbx_path
        self.data_storage['Metadata']['blend_path'] = bpy.data.filepath.split(
            '\\')[-1]

        self.data_storage['Language'] = {}
        self.data_storage['Language']['instructions'] = context.scene.hsi_properties.language_instructions
        self.data_storage['Language']['timepoints'] = []
        context.scene.hsi_properties.current_instruction_index = 0
        self.last_instruction_time = time.time()

        self.data_storage['Human'] = {'Hip translation': np.zeros(
            (self.max_frame_num, 3)), 'rotations': np.zeros((self.max_frame_num, 4*len(CC_BONE_NAMES)))}

        self.data_storage['Objects'] = {}

        self.timestamp = time.time()
        print('initializing recording timer...')
        try:
            path = os.path.dirname(os.path.realpath(__file__))
            with open(os.path.join(path, 'hsi_script', 'trans_mats.pkl'), 'rb') as f:
                self.trans_mats_np = pkl.load(f)

            if self.cc_name:
                armature_CC = bpy.data.objects[self.cc_name]
                posebones_CC = armature_CC.pose.bones
                bpy.ops.object.select_all(action='DESELECT')
                armature_CC.select_set(True)
                bpy.context.view_layer.objects.active = armature_CC
                if armature_CC.hide_get():
                    print(f'warning: CC armature hidden! Trying to unhide it.')
                    armature_CC.hide_set(False)
                bpy.ops.object.mode_set(mode='POSE')
                bpy.ops.pose.loc_clear()
                bpy.ops.pose.rot_clear()
                self.data_storage['Metadata']['hand_scale'] = (
                    posebones_CC['CC_Base_L_Hand'].scale[0] + posebones_CC['CC_Base_R_Hand'].scale[0]) / 2
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.transform_apply(
                    location=False, rotation=False, scale=True)
                time.sleep(0.1)
                for segmentName in CC_BONE_NAMES:
                    self.trans_mats[segmentName] = Matrix(
                        self.trans_mats_np[segmentName])
                    bone = posebones_CC[segmentName]
                    bone.rotation_mode = 'QUATERNION'
            print('trans_mats between shogun armature and CC armature read')
        except Exception as e:
            print(e)
            traceback.print_exc()
            context.scene.hsi_properties.streaming_state = 'IDLING'
            return {'RUNNING_MODAL'}

        try:
            client = ViconDataStream.Client()
            self.client = client
            client.Connect('localhost:801')
            print('Version', client.GetVersion())
            client.SetBufferSize(1)
            client.EnableSegmentData()
            client.EnableMarkerData()
            client.EnableUnlabeledMarkerData()
            time.sleep(0.01)
            HasFrame = False
            while not HasFrame:
                try:
                    client.GetFrame()
                    HasFrame = True
                except ViconDataStream.DataStreamException as e:
                    client.GetFrame()

            client.SetStreamMode(ViconDataStream.Client.StreamMode.EServerPush)
            client.SetAxisMapping(ViconDataStream.Client.AxisMapping.EForward,
                                  ViconDataStream.Client.AxisMapping.ELeft, ViconDataStream.Client.AxisMapping.EUp)
            print('Vicon connection configured')
        except ViconDataStream.DataStreamException as e:
            print('Handled data stream error', e)
            context.scene.hsi_properties.streaming_state = 'IDLING'
            return {'RUNNING_MODAL'}

        try:
            subjectNames = client.GetSubjectNames()
            for subjectName in subjectNames:
                if subjectName == self.shogun_name:
                    continue
                for obj in bpy.data.objects:
                    if f'{subjectName}_root' in obj.name:
                        self.subject_name_to_root_name[subjectName] = obj.name
                        obj.rotation_mode = "QUATERNION"
                        self.data_storage['Objects'][obj.name] = np.zeros(
                            (self.max_frame_num, 7))
                        break
            print('running well...')
        except Exception as e:
            context.scene.hsi_properties.streaming_state = 'IDLING'
            return {'RUNNING_MODAL'}

        return {'RUNNING_MODAL'}

    def cancel(self, context):
        wm = context.window_manager
        wm.event_timer_remove(self._timer)
        context.scene.hsi_properties.streaming_state = 'IDLING'
        try:
            self.data_storage['Language']['timepoints'] = hsi_script.eliminate_bounce(
                self.data_storage['Language']['timepoints'], len(self.data_storage['Language']['instructions'].split('\n'))-1, int(self.fps))
            context.scene.hsi_properties.instruction_timepoints = ', '.join(
                map(str, self.data_storage['Language']['timepoints']))
            assert len(self.data_storage['Language']['instructions'].split(
                '\n')) == len(self.data_storage['Language']['timepoints']) + 1
        except:
            l = len(self.data_storage['Language']['instructions'].split('\n'))
            self.report(
                {"WARNING"}, f"Unmatch timepoint number ({l}) and instruction number ({len(self.data_storage['Language']['timepoints'])})")

        try:
            filepath_root = context.scene.hsi_properties.recordings_path
            cur = datetime.datetime.fromtimestamp(time.time()).isoformat('@')
            datetime_str = cur[0:19].replace(':', '-')
            filepath = os.path.join(filepath_root, f'{datetime_str}.pkl')

            self.data_storage['Metadata']['frame_num'] = self.frame_num
            self.data_storage['Metadata']['fps'] = self.fps
            for key in self.data_storage['Human'].keys():
                self.data_storage['Human'][key] = self.data_storage['Human'][key][:self.frame_num]
            for key in self.data_storage['Objects'].keys():
                self.data_storage['Objects'][key] = self.data_storage['Objects'][key][:self.frame_num]

            with open(filepath, 'wb') as f:
                pkl.dump(self.data_storage, f, pkl.HIGHEST_PROTOCOL)
            bpy.context.scene.hsi_properties.restore_file_path = filepath
            print(
                f'Recording ended at frame {self.frame_num}, saved at {filepath}')
        except Exception as e:
            print(e)


class LiveModalTimerOperator(bpy.types.Operator):
    """Operator which runs itself from a timer"""
    bl_idname = "wm.live_modal_timer_operator"
    bl_label = "Start Livestream"

    _timer = None

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.streaming_state == 'IDLING'

    def modal(self, context, event):
        if context.scene.hsi_properties.streaming_state == 'IDLING':
            self.cancel(context)
            return {'CANCELLED'}

        if event.type == 'TIMER':

            if self.frame_num == 0:
                self.timestamp = time.time()
            elif self.frame_num == int(self.fps):
                delta_time = time.time() - self.timestamp
                real_fps = self.fps/delta_time
                self.fps_running_mean = real_fps
                print(
                    f'frame:{int(self.frame_num)}, real fps:{real_fps:.2f}, running mean:{self.fps_running_mean:.2f} expected fps:{self.fps}')
                self.timestamp = time.time()
                if real_fps < 0.95*self.fps:
                    self.report(
                        {'WARNING'}, f'Low fps! Real:{real_fps:.2f} Runnning mean:{self.fps_running_mean:.2f} Expected:{self.fps} ')
            elif self.frame_num % int(self.fps) == 0:
                delta_time = time.time() - self.timestamp
                real_fps = self.fps/delta_time
                self.fps_running_mean = real_fps * 0.25 + self.fps_running_mean * 0.75
                print(
                    f'frame:{int(self.frame_num)}, real fps:{real_fps:.2f}, running mean:{self.fps_running_mean:.2f} expected fps:{self.fps}')
                self.timestamp = time.time()
                if real_fps < 0.95*self.fps:
                    self.report(
                        {'WARNING'}, f'Low fps! Real:{real_fps:.2f} Runnning mean:{self.fps_running_mean:.2f} Expected:{self.fps} ')

            try:
                client = self.client

                client.GetFrame()
            except Exception as e:
                print(e)
                self.cancel(context)
                return {'CANCELLED'}

            try:
                armature_CC = bpy.data.objects[self.cc_name]
            except Exception as e:
                print(f'CC character named {self.cc_name} not found!')
                self.cancel(context)
                return {'CANCELLED'}

            try:
                subjectNames = client.GetSubjectNames()

                for subjectName in subjectNames:
                    if subjectName == self.shogun_name:
                        continue
                    segmentNames = client.GetSegmentNames(subjectName)
                    assert len(segmentNames) == 1
                    segmentName = segmentNames[0]
                    transl, _ = client.GetSegmentGlobalTranslation(
                        subjectName, segmentName)
                    rot, _ = client.GetSegmentGlobalRotationMatrix(
                        subjectName, segmentName)

                    if subjectName in self.subject_name_to_root_name.keys():
                        obj = bpy.data.objects[self.subject_name_to_root_name[subjectName]]
                        obj.location = Vector(transl) / 1000.
                        obj.rotation_quaternion = Matrix(rot).to_quaternion()
                    else:
                        if self.frame_num % int(self.fps) == 0:
                            print(
                                f'warning: shogun subject \'{subjectName}\' not matching any object in blender.')

                ### marker debug start ###
                if context.scene.hsi_properties.is_marker_debugging_now:
                    for subjectName in subjectNames:
                        markerNames = client.GetMarkerNames(subjectName)
                        # print(subjectName,markerNames)
                        for mname_tuple in markerNames:
                            mname = mname_tuple[0]
                            name = f'marker_{mname}_{subjectName}'
                            # print(name)
                            if name not in bpy.data.objects:
                                bpy.ops.mesh.primitive_uv_sphere_add(
                                    enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(0.007, 0.007, 0.007))
                                bpy.context.view_layer.objects.active.name = name
                                bpy.data.objects[name].show_in_front = True
                            obj = bpy.data.objects[name]
                            markerPos, _ = client.GetMarkerGlobalTranslation(
                                subjectName, mname)
                            obj.location = Vector(markerPos)/1000
                ### marker debug end ###

                for subjectName in subjectNames:
                    if subjectName != self.shogun_name:
                        continue

                    for index, segmentName in enumerate(CC_BONE_NAMES):
                        bone = armature_CC.pose.bones[segmentName]
                        if segmentName == 'CC_Base_Hip':
                            transl, _ = client.GetSegmentGlobalTranslation(
                                subjectName, segmentName)
                            loc = Vector(transl)/1000
                            bone.location = (loc[0], loc[2], -loc[1])
                        rot_mat_static = client.GetSegmentStaticRotationMatrix(
                            subjectName, segmentName)
                        rot_mat_local, _ = client.GetSegmentLocalRotationMatrix(
                            subjectName, segmentName)

                        trans_mat = self.trans_mats[segmentName]
                        bone.rotation_quaternion = (
                            trans_mat @ Matrix(rot_mat_static).inverted() @ Matrix(rot_mat_local)).to_quaternion()
                self.frame_num += 1

            except Exception as e:
                print(e)
                self.cancel(context)
                print(traceback.format_exc())
                return {'CANCELLED'}

        return {'PASS_THROUGH'}

    def execute(self, context):
        context.scene.hsi_properties.streaming_state = 'LIVE'
        wm = context.window_manager
        self.fps = context.scene.hsi_properties.recording_fps
        self._timer = wm.event_timer_add(1.0/self.fps, window=context.window)
        wm.modal_handler_add(self)

        self.shogun_name = bpy.context.scene.hsi_properties.shogun_subject_name
        self.cc_name = bpy.context.scene.hsi_properties.name_armature_CC
        self.trans_mats = {}
        self.subject_name_to_root_name = {}
        self.frame_num = 0

        print('initializing live streaming timer...')
        try:
            path = os.path.dirname(os.path.realpath(__file__))
            with open(os.path.join(path, 'hsi_script', 'trans_mats.pkl'), 'rb') as f:
                self.trans_mats_np = pkl.load(f)

            if self.cc_name:
                armature_CC = bpy.data.objects[self.cc_name]
                posebones_CC = armature_CC.pose.bones
                bpy.ops.object.select_all(action='DESELECT')
                armature_CC.select_set(True)
                bpy.context.view_layer.objects.active = armature_CC
                if armature_CC.hide_get():
                    print(f'warning: CC armature hidden! Trying to unhide it.')
                    armature_CC.hide_set(False)
                bpy.ops.object.mode_set(mode='POSE')
                bpy.ops.pose.loc_clear()
                bpy.ops.pose.rot_clear()
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.transform_apply(
                    location=False, rotation=False, scale=True)
                time.sleep(0.1)
                for segmentName in CC_BONE_NAMES:
                    self.trans_mats[segmentName] = Matrix(
                        self.trans_mats_np[segmentName])
                    bone = posebones_CC[segmentName]
                    bone.rotation_mode = 'QUATERNION'
            print('trans_mats between shogun armature and CC armature read')
        except Exception as e:
            print(e)
            traceback.print_exc()
            context.scene.hsi_properties.streaming_state = 'IDLING'
            return {'RUNNING_MODAL'}

        try:
            client = ViconDataStream.Client()
            self.client = client
            client.Connect('localhost:801')
            print('Version', client.GetVersion())
            client.SetBufferSize(1)
            client.EnableSegmentData()
            client.EnableMarkerData()
            client.EnableUnlabeledMarkerData()
            time.sleep(0.01)
            HasFrame = False
            while not HasFrame:
                try:
                    client.GetFrame()
                    HasFrame = True
                except ViconDataStream.DataStreamException as e:
                    client.GetFrame()

            client.SetStreamMode(ViconDataStream.Client.StreamMode.EServerPush)
            client.SetAxisMapping(ViconDataStream.Client.AxisMapping.EForward,
                                  ViconDataStream.Client.AxisMapping.ELeft, ViconDataStream.Client.AxisMapping.EUp)
            print('Vicon connection configured')
        except ViconDataStream.DataStreamException as e:
            print('Handled data stream error', e)
            context.scene.hsi_properties.streaming_state = 'IDLING'
            return {'RUNNING_MODAL'}

        try:
            subjectNames = client.GetSubjectNames()
            for subjectName in subjectNames:
                if subjectName == self.shogun_name:
                    continue
                for obj in bpy.data.objects:
                    if f'{subjectName}_root' in obj.name:
                        self.subject_name_to_root_name[subjectName] = obj.name
                        obj.rotation_mode = "QUATERNION"
                        break
            print('running well...')
        except Exception as e:
            context.scene.hsi_properties.streaming_state = 'IDLING'
            return {'RUNNING_MODAL'}

        return {'RUNNING_MODAL'}

    def cancel(self, context):
        wm = context.window_manager
        wm.event_timer_remove(self._timer)
        context.scene.hsi_properties.streaming_state = 'IDLING'
        print('Live streaming ended.')


class HSI_OT_stop_livestream(bpy.types.Operator):
    bl_idname = "hsi.stop_livestream"
    bl_label = "Stop Livestream"
    bl_description = "Stop Livestreaming."

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.streaming_state == 'LIVE'

    def execute(self, context):
        context.scene.hsi_properties.streaming_state = 'IDLING'
        return {'FINISHED'}


class HSI_OT_deactivate_marker_debug(bpy.types.Operator):
    bl_idname = "hsi.deactivate_marker_debug"
    bl_label = "No Marker"
    bl_description = "Deactivate marker debugging"

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.is_marker_debugging_now

    def execute(self, context):
        context.scene.hsi_properties.is_marker_debugging_now = False
        bpy.ops.object.select_all(action='DESELECT')
        for obj in bpy.data.objects:
            if obj.name.startswith('marker_'):
                obj.select_set(True)
        bpy.ops.object.delete()
        return {'FINISHED'}


class HSI_OT_activate_marker_debug(bpy.types.Operator):
    bl_idname = "hsi.activate_marker_debug"
    bl_label = "Marker Debug"
    bl_description = "Activate marker debugging"

    @classmethod
    def poll(cls, context):
        return not context.scene.hsi_properties.is_marker_debugging_now

    def execute(self, context):
        context.scene.hsi_properties.is_marker_debugging_now = True
        return {'FINISHED'}


class HSI_OT_load_smplx_animation(bpy.types.Operator, ImportHelper):
    bl_idname = "hsi.load_smplx_animation"
    bl_label = "Load SMPL-X Animation"
    bl_description = ("Create SMPL-X body, set betas, and load animatino")
    bl_options = {'REGISTER', 'UNDO'}

    filter_glob: StringProperty(
        default="*.pkl",
        options={'HIDDEN'}
    )

    keyframe_corrective_pose_weights: BoolProperty(
        name="Use keyframed corrective pose weights",
        description="Keyframe the weights of the corrective pose shapes for each frame. This increases animation load time and slows down editor real-time playback.",
        default=False
    )

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.streaming_state == 'IDLING'

    def execute(self, context):

        with open(self.filepath, 'rb') as f:
            data = pkl.load(f)
        
        armature, mesh_obj = hsi_script.add_smplx_human(
            data['gender'], data['betas'])

        hsi_script.load_smplx_animation(
            armature, mesh_obj, data, self.keyframe_corrective_pose_weights)

        context.scene.frame_set(0)
        return {'FINISHED'}


class HSI_OT_end_recording(bpy.types.Operator):
    bl_idname = "hsi.end_recording"
    bl_label = "End Recording"
    bl_description = "End the current recording"

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.streaming_state == 'RECORDING'

    def execute(self, context):
        context.scene.hsi_properties.streaming_state = 'IDLING'
        return {'FINISHED'}


class HSI_OT_restore_capture(bpy.types.Operator):
    bl_idname = "hsi.restore_capture"
    bl_label = "Restore capture"
    bl_description = "Restore poses of human and objects according to one capture. If the current Shogun fbx doesn't match the one used in the capture, it will cause an error."

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.streaming_state == 'IDLING'

    def execute(self, context):
        restore_file_path = context.scene.hsi_properties.restore_file_path
        # check if animation already exists
        if os.path.split(restore_file_path)[-1] in json.loads(bpy.context.scene.hsi_properties.animation_sets).keys():
            self.report({'ERROR'}, f'This animation already exists!')
            return {'CANCELLED'}

        with open(restore_file_path, 'rb') as f:
            restore_data = pkl.load(f)
        bpy.context.scene.frame_end = restore_data['Metadata']['frame_num']-1
        bpy.context.scene.frame_start = 0
        armature_CC = bpy.data.objects[context.scene.hsi_properties.name_armature_CC]
        name_list = list(restore_data['Objects'].keys())
        name_list.append(armature_CC.name)

        # make way for new animation set coming in
        for obj_name in name_list:
            if bpy.data.objects[obj_name].animation_data is not None:
                bpy.data.objects[obj_name].animation_data.action = None

        # insert new data
        try:
            # language part
            context.scene.hsi_properties.language_instructions = restore_data[
                'Language']['instructions']
            context.scene.hsi_properties.instruction_timepoints = ', '.join(
                map(str, restore_data['Language']['timepoints']))
        except KeyError as e:
            self.report(
                {'WARNING'}, f'Possibly early version without language instruction loaded. Original error: {e}')

        hsi_script.restore_recording(restore_data, armature_CC)
        bpy.context.scene.frame_set(0)

        # use fake user, add to existent animation set
        for obj_name in name_list:
            bpy.data.objects[obj_name].animation_data.action.use_fake_user = True

        animation_set = json.loads(context.scene.hsi_properties.animation_sets)
        animation_set[os.path.split(restore_file_path)[-1]] = {
            obj_name: bpy.data.objects[obj_name].animation_data.action.name for obj_name in name_list}
        context.scene.hsi_properties.animation_sets = json.dumps(animation_set)
        context.scene.hsi_properties.current_animation_index_display = len(
            animation_set)-1
        context.scene.hsi_properties.current_animation_index = len(
            animation_set)-1

        return {'FINISHED'}


class HSI_OT_apply_physics(bpy.types.Operator):
    bl_idname = "hsi.apply_physics"
    bl_label = "Apply physics"
    bl_description = "Apply physics to the current character"

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.streaming_state == 'IDLING' and not context.scene.hsi_properties.is_physics_enabled

    def execute(self, context):
        bpy.ops.cc3.setphysics(param='APPLY_PHYSICS')
        context.scene.hsi_properties.is_physics_enabled = True
        return {'FINISHED'}


class HSI_OT_remove_physics(bpy.types.Operator):
    bl_idname = "hsi.remove_physics"
    bl_label = "Remove physics"
    bl_description = "Remove physics from the current character"

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.is_physics_enabled

    def execute(self, context):
        bpy.ops.cc3.setphysics(param='REMOVE_PHYSICS')
        context.scene.hsi_properties.is_physics_enabled = False
        return {'FINISHED'}


class HSI_OT_generate_instructions(bpy.types.Operator):
    bl_idname = "hsi.generate_instructions"
    bl_label = "Generate Instructions"
    bl_description = "Generate instructions given the objects in the scene"

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.streaming_state == 'IDLING'

    def execute(self, context):
        objects = context.scene.hsi_properties.scene_objects
        objects = objects.split(' ')
        try:
            instructions = hsi_script.generate_instruction(objects)
        except Exception as e:
            print(traceback.format_exc())
            self.report(
                {"ERROR"}, f"输入的物体格式不正确。当前输入为：\"{context.scene.hsi_properties.scene_objects}\"。\n错误信息：{e}")
            return {'CANCELLED'}
        context.scene.hsi_properties.language_instructions = '\n'.join(
            instructions)
        return {'FINISHED'}


class HSI_OT_clear_all_animation(bpy.types.Operator):
    bl_idname = "hsi.clear_all_animation"
    bl_label = "Clear All Animation"
    bl_description = "Clear all animation in the scene"

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.streaming_state == 'IDLING'

    def execute(self, context):
        for obj in bpy.data.objects:
            obj.animation_data_clear()

        bpy.context.view_layer.update()

        # warning: this cleaning code may be dangerous !
        for block in bpy.data.actions:
            bpy.data.actions.remove(block)

        bpy.context.scene.hsi_properties.animation_sets = '{}'

        return {'FINISHED'}

    def invoke(self, context, event):
        # Show the confirmation dialog
        return context.window_manager.invoke_confirm(self, event)


class HSI_OT_remove_animation(bpy.types.Operator):
    bl_idname = "hsi.remove_animation"
    bl_label = "Remove Current"
    bl_description = "Remove current animation set"

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.streaming_state == 'IDLING'\
            and len(json.loads(bpy.context.scene.hsi_properties.animation_sets).keys()) != 0

    def execute(self, context):
        animation_sets: dict = json.loads(
            bpy.context.scene.hsi_properties.animation_sets)
        animation_index = bpy.context.scene.hsi_properties.current_animation_index
        if animation_index >= len(animation_sets.keys()):
            self.report(
                {'ERROR'}, f'Animation index {bpy.context.scene.hsi_properties.current_animation_index} out of range')
            return {'CANCELLED'}

        animation_key = list(animation_sets.keys())[animation_index]
        for obj_name, action_name in animation_sets[animation_key].items():
            bpy.data.actions.remove(bpy.data.actions[action_name])
        animation_sets.pop(animation_key)
        bpy.context.scene.hsi_properties.animation_sets = json.dumps(
            animation_sets)

        return {'FINISHED'}


class HSI_OT_set_animation(bpy.types.Operator):
    bl_idname = "hsi.set_animation"
    bl_label = "Set Action"
    bl_description = "Set chosen animation set"

    @classmethod
    def poll(cls, context):
        return context.scene.hsi_properties.streaming_state == 'IDLING' \
            and bpy.context.scene.hsi_properties.current_animation_index_display < len(json.loads(bpy.context.scene.hsi_properties.animation_sets))

    def execute(self, context):
        if bpy.context.scene.hsi_properties.current_animation_index == bpy.context.scene.hsi_properties.current_animation_index_display:
            return {'FINISHED'}
        animation_sets: dict = json.loads(
            bpy.context.scene.hsi_properties.animation_sets)
        animation_index_display = bpy.context.scene.hsi_properties.current_animation_index_display
        animation_index = bpy.context.scene.hsi_properties.current_animation_index

        if animation_index_display >= len(animation_sets.keys()):
            self.report(
                {'ERROR'}, f'Animation index {bpy.context.scene.hsi_properties.animation_index_display} out of range')
            return {'CANCELLED'}
        animation_key = list(animation_sets.keys())[animation_index_display]
        for obj_name, action_name in animation_sets[animation_key].items():
            bpy.data.objects[obj_name].animation_data.action = bpy.data.actions[action_name]

        bpy.context.scene.hsi_properties.current_animation_index = animation_index_display
        bpy.context.scene.frame_end = int(
            bpy.data.objects[obj_name].animation_data.action.frame_range[1])

        return {'FINISHED'}


classes = (
    HSI_OT_import_character,
    HSI_OT_calibrate_CC_Shogun_armatures,
    LiveModalTimerOperator,
    HSI_OT_calculate_CC_slider_values,
    HSI_OT_pick_CC_armature,
    HSI_OT_remove_character,
    RecordModalTimerOperator,
    HSI_OT_end_recording,
    HSI_OT_deactivate_marker_debug,
    HSI_OT_activate_marker_debug,
    HSI_OT_stop_livestream,
    # HSI_OT_calibrate_CC_restore,
    HSI_OT_restore_capture,
    HSI_OT_pick_VR_camera,
    CalibrateVRModalTimerOperator,
    HSI_OT_apply_physics,
    HSI_OT_remove_physics,
    HSI_OT_clear_all_animation,
    HSI_OT_remove_animation,
    HSI_OT_set_animation,
    HSI_OT_generate_instructions,
    HSI_OT_load_smplx_animation
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)


if __name__ == '__main__':
    register()
